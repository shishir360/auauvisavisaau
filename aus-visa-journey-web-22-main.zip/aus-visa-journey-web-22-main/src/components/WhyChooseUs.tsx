import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle, Users, Award, Clock, Shield, FileCheck } from 'lucide-react';

export const WhyChooseUs = () => {
  const benefits = [
    {
      icon: CheckCircle,
      title: 'Free Initial Visa Consultation',
      description: 'Initial FREE consultation with our migration agent to better understand your situation and provide advice on various options within your circumstances.'
    },
    {
      icon: Users,
      title: 'Professional Migration Advice',
      description: 'Our experts are friendly, approachable and ready to provide clear, honest and accurate advice. We assess your circumstances carefully before providing guidance.'
    },
    {
      icon: Award,
      title: 'Registered Migration Agent',
      description: 'Our team of registered migration agents provide honest and frank advice. We strictly follow the Code of Conduct laid out by OMARA.'
    },
    {
      icon: Clock,
      title: 'International Student Support',
      description: 'Our team guides you through the process and helps you settle into your new school. We have successfully helped hundreds with their student visa process.'
    },
    {
      icon: Shield,
      title: 'Experienced Team',
      description: 'We ensure you follow the right pathway with up-to-date Australian Government Immigration Policy information and receive guidance at the right time.'
    },
    {
      icon: FileCheck,
      title: 'Australian Visas Checklist',
      description: 'We provide you with a checklist and timeline for visa applications. We are qualified to certify all copies of documents to be submitted.'
    }
  ];

  return (
    <section className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">
            Why Choose <span className="text-primary">S&S Consultation Pvt. Ltd</span>?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Benefit from our 20 years of experience in Australian immigration law and visa applications.
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <Card key={index} className="group hover:shadow-strong transition-all duration-300 border-0 shadow-soft">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-gradient-ocean rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                    <Icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-4">
                    {benefit.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {benefit.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Experience Highlight */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-sunset rounded-2xl p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl sm:text-3xl font-bold text-navy-dark mb-4">
              20+ Years of Immigration Experience
            </h3>
            <p className="text-navy-dark/80 text-lg">
              Our Perth-based team has successfully guided hundreds of clients through their visa journey. 
              We treat our clients as trusted associates and cultivate long-lasting friendships.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};