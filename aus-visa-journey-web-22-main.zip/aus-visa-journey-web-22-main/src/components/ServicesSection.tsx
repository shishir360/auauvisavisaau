import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { GraduationCap, Users, Briefcase, Building, Plane, ArrowRight } from 'lucide-react';
import studyVisa from '@/assets/study-visa.jpg';
import familyVisa from '@/assets/family-visa.jpg';
import skilledVisa from '@/assets/skilled-visa.jpg';
import businessVisa from '@/assets/business-visa.jpg';

export const ServicesSection = () => {
  const services = [
    {
      icon: GraduationCap,
      title: 'Study Visas',
      description: 'We can assist with your study visa application and help with your relocation to Australia.',
      image: studyVisa,
      color: 'text-ocean-blue'
    },
    {
      icon: Users,
      title: 'Family Visas',
      description: 'Australia is a safe and supportive country making it a fantastic place to raise your family.',
      image: familyVisa,
      color: 'text-accent'
    },
    {
      icon: Briefcase,
      title: 'Skilled & Work Visas',
      description: 'Looking for amazing career opportunities and a fair workplace? Look no further than Australia.',
      image: skilledVisa,
      color: 'text-golden-yellow'
    },
    {
      icon: Building,
      title: 'Business & Investment Visas',
      description: 'Australia provides a range of business investment visa options and we help get your application approved.',
      image: businessVisa,
      color: 'text-primary'
    },
    {
      icon: Plane,
      title: 'Other Visa Options',
      description: 'Looking for travel or working holiday visas? S&S Consultation Pvt. Ltd can assist with various visa types.',
      image: studyVisa,
      color: 'text-secondary'
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">
            We Simplify the <span className="text-primary">Visa Process</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Australia is one of the greatest countries in the world, and there has never been a better time to migrate. 
            Whether you are a skilled professional, business investor, or student, we can simplify the visa process.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card key={index} className="group hover:shadow-strong transition-all duration-300 border-0 shadow-soft overflow-hidden">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-4 left-4">
                    <Icon className={`h-8 w-8 ${service.color}`} />
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-foreground mb-3 group-hover:text-primary transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* CTA */}
        <div className="text-center">
          <Button size="lg" className="px-8 py-6 text-lg shadow-soft">
            View All Services
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  );
};