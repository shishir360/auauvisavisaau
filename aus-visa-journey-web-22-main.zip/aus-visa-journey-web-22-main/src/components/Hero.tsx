import { Button } from '@/components/ui/button';
import { ArrowRight, Star } from 'lucide-react';

import heroBeach from '@/assets/hero-beach.jpg';

export const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroBeach})` }}
      >
        <div className="absolute inset-0 bg-gradient-hero opacity-80" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="max-w-3xl">
          {/* Trust Badge */}
          <div className="flex items-center space-x-2 mb-6">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 text-golden-yellow fill-current" />
              ))}
            </div>
            <span className="text-white/90 text-sm font-medium">
              Trusted by 500+ successful applicants
            </span>
          </div>

          {/* Main Heading */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
            Australian Visa{' '}
            <span className="text-golden-yellow">Simplified</span>
          </h1>

          {/* Subheading */}
          <p className="text-xl sm:text-2xl text-white/90 mb-8 leading-relaxed">
            We can help you get your visa quicker. Perth-based consultants who focus on making your visa application simple and straightforward.
          </p>

          {/* Key Message */}
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg p-6 mb-8">
            <p className="text-white font-medium text-lg">
              ✨ There has never been a better time to move to Australia
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button 
              size="lg" 
              className="bg-golden-yellow hover:bg-golden-yellow/90 text-navy-dark font-semibold px-8 py-6 text-lg shadow-strong"
              asChild
            >
              <a href="/visa-application">
                Book Free Consultation
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="border-primary/50 text-primary bg-white/90 hover:bg-white hover:text-primary/80 px-8 py-6 text-lg backdrop-blur-sm font-semibold"
            >
              Learn More About Services
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-6 mt-12 pt-8 border-t border-white/20">
            <div className="text-center">
              <div className="text-2xl sm:text-3xl font-bold text-golden-yellow">20+</div>
              <div className="text-white/80 text-sm">Years Experience</div>
            </div>
            <div className="text-center">
              <div className="text-2xl sm:text-3xl font-bold text-golden-yellow">500+</div>
              <div className="text-white/80 text-sm">Successful Applications</div>
            </div>
            <div className="text-center col-span-2 sm:col-span-1">
              <div className="text-2xl sm:text-3xl font-bold text-golden-yellow">100%</div>
              <div className="text-white/80 text-sm">Registered Agents</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};