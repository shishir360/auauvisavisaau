import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Send } from 'lucide-react';

export const ContactForm = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    toast({
      title: "Consultation Request Sent!",
      description: "We'll contact you within 24 hours to schedule your free consultation.",
    });
    
    setIsSubmitting(false);
  };

  return (
    <Card className="shadow-strong border-0">
      <CardHeader>
        <CardTitle className="text-2xl text-center">
          Get Your <span className="text-primary">Free Consultation</span>
        </CardTitle>
        <p className="text-muted-foreground text-center">
          Fill out the form below and our experts will contact you within 24 hours.
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input id="name" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input id="phone" type="tel" />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email Address *</Label>
            <Input id="email" type="email" required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="nationality">Nationality</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Select your nationality" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="indian">Indian</SelectItem>
                <SelectItem value="chinese">Chinese</SelectItem>
                <SelectItem value="malaysian">Malaysian</SelectItem>
                <SelectItem value="singaporean">Singaporean</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="service">Service Required *</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Choose service type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="education">Education</SelectItem>
                <SelectItem value="visa-application">Visa Application</SelectItem>
                <SelectItem value="study-option">Study Option</SelectItem>
                <SelectItem value="graduate-visa">Graduate Visa</SelectItem>
                <SelectItem value="partner-visa">Partner Visa</SelectItem>
                <SelectItem value="skilled-visa">Skilled Visa</SelectItem>
                <SelectItem value="business-visa">Business Visa</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="enquiry">Your Enquiry</Label>
            <Textarea 
              id="enquiry" 
              placeholder="Tell us about your visa requirements..."
              className="min-h-[120px]"
            />
          </div>

          <Button 
            type="submit" 
            className="w-full py-6 text-lg"
            disabled={isSubmitting}
          >
            {isSubmitting ? "Sending..." : "Send Enquiry"}
            <Send className="ml-2 h-5 w-5" />
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};