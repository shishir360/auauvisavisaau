import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X, Phone, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";

export const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const currentPath = window.location.pathname;

  const navigation = [
    { name: 'Home', href: '/' },
    { name: 'About Us', href: '/about' },
    { name: 'Blog', href: '/blog' },
    { name: 'Contact', href: '/contact' },
    { name: 'Apply Now', href: '/visa-application' },
  ];

  const visaServices = [
    { name: 'Study Visas', href: '/visa-services/study' },
    { name: 'Skilled & Work Visas', href: '/visa-services/skilled-work' },
    { name: 'Family Visas', href: '/visa-services/family' },
    { name: 'Partner Visas', href: '/visa-services/partner' },
    { name: 'Business & Investments Visas Australia', href: '/visa-services/business' },
    { name: 'Other Visas', href: '/visa-services/other' },
    { name: 'Other Immigration Services', href: '/visa-services/immigration' },
  ];

  const studentServices = [
    { name: 'Student Placement', href: '/student-services#placement' },
    { name: 'Student Visa Application Process', href: '/student-services#application' },
    { name: 'Student Accommodation', href: '/student-services#accommodation' },
    { name: 'Jobs for Students', href: '/student-services#jobs' },
  ];

  const isActive = (href: string) => currentPath === href;

  return (
    <nav className="fixed w-full z-50 bg-background/95 backdrop-blur border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <a href="/" className="flex items-center space-x-2">
            <div className="bg-gradient-ocean text-white px-3 py-1 rounded-lg font-bold">
              S&S Consultation
            </div>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <NavigationMenu>
              <NavigationMenuList>
                {/* Regular navigation items */}
                {navigation.map((item) => (
                  <NavigationMenuItem key={item.name}>
                    <a
                      href={item.href}
                      className={cn(
                        "text-sm font-medium transition-colors hover:text-primary px-4 py-2",
                        isActive(item.href) 
                          ? "text-primary" 
                          : "text-muted-foreground"
                      )}
                    >
                      {item.name}
                    </a>
                  </NavigationMenuItem>
                ))}

                {/* Australian Visa Services Mega Menu */}
                <NavigationMenuItem>
                  <NavigationMenuTrigger className="text-sm font-medium text-muted-foreground hover:text-primary">
                    Australian Visa Services
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <div className="grid w-[400px] p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px] gap-3">
                      {visaServices.map((service) => (
                        <a
                          key={service.name}
                          href={service.href}
                          className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                        >
                          <div className="text-sm font-medium leading-none">{service.name}</div>
                        </a>
                      ))}
                    </div>
                  </NavigationMenuContent>
                </NavigationMenuItem>

                {/* Student Services Mega Menu */}
                <NavigationMenuItem>
                  <NavigationMenuTrigger className="text-sm font-medium text-muted-foreground hover:text-primary">
                    Student Services
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <div className="grid w-[400px] p-4 md:w-[500px] md:grid-cols-1 lg:w-[600px] gap-3">
                      <div className="mb-3">
                        <a
                          href="/student-services"
                          className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground bg-muted"
                        >
                          <div className="text-sm font-medium leading-none">Student Services Overview</div>
                          <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                            Comprehensive support for international students
                          </p>
                        </a>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        {studentServices.map((service) => (
                          <a
                            key={service.name}
                            href={service.href}
                            className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                          >
                            <div className="text-sm font-medium leading-none">{service.name}</div>
                          </a>
                        ))}
                      </div>
                    </div>
                  </NavigationMenuContent>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
          </div>

          {/* Contact Info & CTA */}
          <div className="hidden md:flex items-center space-x-4">
            <div className="flex items-center text-sm text-muted-foreground">
              <Phone className="h-4 w-4 mr-1" />
              +61 481 826 365
            </div>
            <Button variant="default" size="sm">
              Free Consultation
            </Button>
          </div>

          {/* Mobile menu button */}
          <Button
            variant="ghost"
            size="sm"
            className="md:hidden"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden border-t border-border bg-background/95 backdrop-blur">
            <div className="px-2 pt-2 pb-3 space-y-1 max-h-screen overflow-y-auto">
              {/* Regular navigation items */}
              {navigation.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className={cn(
                    "block px-3 py-3 text-base font-medium rounded-md transition-colors",
                    isActive(item.href)
                      ? "text-primary bg-accent"
                      : "text-muted-foreground hover:text-primary hover:bg-accent"
                  )}
                  onClick={() => setIsOpen(false)}
                >
                  {item.name}
                </a>
              ))}
              
              {/* Visa Services */}
              <div className="border-t border-border pt-3 mt-3">
                <div className="px-3 py-2 text-sm font-semibold text-foreground">
                  Australian Visa Services
                </div>
                {visaServices.map((service) => (
                  <a
                    key={service.name}
                    href={service.href}
                    className="block px-6 py-2 text-sm text-muted-foreground hover:text-primary hover:bg-accent rounded-md transition-colors"
                    onClick={() => setIsOpen(false)}
                  >
                    {service.name}
                  </a>
                ))}
              </div>

              {/* Student Services */}
              <div className="border-t border-border pt-3 mt-3">
                <div className="px-3 py-2 text-sm font-semibold text-foreground">
                  Student Services
                </div>
                <a
                  href="/student-services"
                  className="block px-6 py-2 text-sm text-muted-foreground hover:text-primary hover:bg-accent rounded-md transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  Student Services Overview
                </a>
                {studentServices.map((service) => (
                  <a
                    key={service.name}
                    href={service.href}
                    className="block px-6 py-2 text-sm text-muted-foreground hover:text-primary hover:bg-accent rounded-md transition-colors"
                    onClick={() => setIsOpen(false)}
                  >
                    {service.name}
                  </a>
                ))}
              </div>

              {/* CTA Button */}
              <div className="px-3 py-4 border-t border-border mt-3">
                <Button variant="default" className="w-full" onClick={() => setIsOpen(false)}>
                  Free Consultation
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};