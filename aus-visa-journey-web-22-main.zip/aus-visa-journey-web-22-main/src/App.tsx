import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import Index from "./pages/Index";
import About from "./pages/About";
import Services from "./pages/Services";
import Contact from "./pages/Contact";
import Blog from "./pages/Blog";
import StudentServices from "./pages/StudentServices";
import VisaApplication from "./pages/VisaApplication";
import NotFound from "./pages/NotFound";
import StudyVisas from "./pages/visa-services/StudyVisas";
import SkilledWorkVisas from "./pages/visa-services/SkilledWorkVisas";
import FamilyVisas from "./pages/visa-services/FamilyVisas";
import PartnerVisas from "./pages/visa-services/PartnerVisas";
import BusinessVisas from "./pages/visa-services/BusinessVisas";
import OtherVisas from "./pages/visa-services/OtherVisas";
import ImmigrationServices from "./pages/visa-services/ImmigrationServices";

const queryClient = new QueryClient();

// Router component to handle page routing based on pathname
const Router = () => {
  const pathname = window.location.pathname;
  
  switch (pathname) {
    case '/':
      return <Index />;
    case '/about':
      return <About />;
    case '/services':
      return <Services />;
    case '/contact':
      return <Contact />;
    case '/blog':
      return <Blog />;
    case '/student-services':
      return <StudentServices />;
    case '/visa-application':
      return <VisaApplication />;
    case '/visa-services/study':
      return <StudyVisas />;
    case '/visa-services/skilled-work':
      return <SkilledWorkVisas />;
    case '/visa-services/family':
      return <FamilyVisas />;
    case '/visa-services/partner':
      return <PartnerVisas />;
    case '/visa-services/business':
      return <BusinessVisas />;
    case '/visa-services/other':
      return <OtherVisas />;
    case '/visa-services/immigration':
      return <ImmigrationServices />;
    default:
      return <NotFound />;
  }
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <Router />
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
