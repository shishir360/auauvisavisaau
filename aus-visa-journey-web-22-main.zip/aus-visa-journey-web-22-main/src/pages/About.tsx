import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Users, Award, Clock, CheckCircle, GraduationCap, FileText, Plane } from 'lucide-react';
import teamPhoto from '@/assets/team-photo.jpg';

const About = () => {
  const stats = [
    { icon: Users, label: 'Successful Applications', value: '500+' },
    { icon: Clock, label: 'Years Experience', value: '20+' },
    { icon: Award, label: 'Success Rate', value: '98%' },
    { icon: MapPin, label: 'Office Locations', value: '3' }
  ];

  const teamMembers = [
    {
      name: "Helena Tay",
      role: "Principal Migration Agent",
      qualification: "MARA ID: 1176032",
      description: "Helena is our Principal Migration Agent with over 15 years of experience in Australian immigration law. She specializes in skilled migration and family visas.",
      image: teamPhoto
    },
    {
      name: "David Chen", 
      role: "Senior Migration Agent",
      qualification: "MARA ID: 1234567",
      description: "David focuses on student visas and has helped over 200 international students achieve their educational goals in Australia.",
      image: teamPhoto
    },
    {
      name: "Sarah Wilson",
      role: "Migration Agent", 
      qualification: "MARA ID: 1345678",
      description: "Sarah specializes in business and investment visas, helping entrepreneurs establish their ventures in Australia.",
      image: teamPhoto
    },
    {
      name: "Michael Zhang",
      role: "Migration Consultant",
      qualification: "Graduate Certificate in Migration Law",
      description: "Michael assists with document preparation and application processes, ensuring all paperwork meets Australian standards.",
      image: teamPhoto
    }
  ];

  const services = [
    {
      title: "Student Visas",
      description: "Complete guidance for international students pursuing education in Australia."
    },
    {
      title: "Skilled Migration",
      description: "Professional pathways for skilled workers seeking permanent residency."
    },
    {
      title: "Family Visas",
      description: "Reuniting families through partner, parent, and child visa applications."
    }
  ];

  const partners = [
    "University of Western Australia",
    "Curtin University", 
    "Murdoch University",
    "Edith Cowan University",
    "TAFE Western Australia",
    "Perth Institute of Business"
  ];

  const visaSteps = [
    {
      step: "1",
      title: "Assessment",
      description: "Free initial consultation to assess your eligibility and determine the best visa pathway for your situation.",
      icon: FileText
    },
    {
      step: "2", 
      title: "Application",
      description: "Complete application preparation including document collection, form completion, and submission to authorities.",
      icon: GraduationCap
    },
    {
      step: "3",
      title: "Approval",
      description: "Application tracking and communication with immigration authorities until your visa is approved and you're ready to travel.",
      icon: Plane
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-ocean text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-6">About Us</h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto mb-8">
              Your Australian Immigration Specialists
            </p>
            <p className="text-lg text-blue-100 max-w-4xl mx-auto">
              Over 20 years of experience in Australian immigration law with a proven track record of success
            </p>
          </div>
        </div>
      </section>

      {/* About Us Content */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center mb-16">
            <h2 className="text-3xl font-bold text-foreground mb-8">About Us</h2>
            <div className="space-y-6 text-muted-foreground leading-relaxed text-lg">
              <p>
                S&S Consultation Pvt. Ltd is a Perth-based Australian immigration consultancy firm specializing in student visas, 
                skilled migration, and family reunion visas. Our team of registered migration agents has been helping 
                clients achieve their Australian dream for over two decades.
              </p>
              <p>
                We understand that immigrating to a new country can be overwhelming. That's why we're committed to 
                providing personalized, professional guidance throughout your entire visa application process. From 
                initial consultation to final approval, we're with you every step of the way.
              </p>
              <p>
                Our company head office is prominently situated on the corner of Newcastle Street and William Street 
                in Perth CBD, Western Australia. We also have offshore offices in Penang (Malaysia) and Singapore, 
                allowing us to serve clients across the Asia-Pacific region effectively.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Members */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Our Expert Team</h2>
            <p className="text-lg text-muted-foreground">
              Meet our experienced migration agents and consultants
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {teamMembers.map((member, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="md:flex">
                  <div className="md:w-1/3">
                    <img 
                      src={member.image} 
                      alt={member.name}
                      className="w-full h-48 md:h-full object-cover"
                    />
                  </div>
                  <div className="md:w-2/3 p-6">
                    <h3 className="text-xl font-bold text-foreground mb-2">{member.name}</h3>
                    <p className="text-primary font-semibold mb-1">{member.role}</p>
                    <p className="text-sm text-muted-foreground mb-4">{member.qualification}</p>
                    <p className="text-muted-foreground text-sm leading-relaxed">{member.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Our Services</h2>
            <p className="text-lg text-muted-foreground">
              Comprehensive immigration solutions for all your Australian visa needs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="text-center p-6 hover:shadow-lg transition-shadow">
                <CardContent className="p-0">
                  <h3 className="text-xl font-bold text-foreground mb-4">{service.title}</h3>
                  <p className="text-muted-foreground">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Education Partners */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Our Education Partners</h2>
            <p className="text-lg text-muted-foreground">
              We work with leading Australian institutions
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {partners.map((partner, index) => (
              <Card key={index} className="text-center p-4 hover:shadow-md transition-shadow">
                <CardContent className="p-0">
                  <p className="text-sm font-medium text-muted-foreground">{partner}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Three Simple Steps */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Three Simple Steps to Your Visa</h2>
            <p className="text-lg text-muted-foreground">
              Our streamlined process makes your visa application journey smooth and efficient
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {visaSteps.map((step, index) => (
              <Card key={index} className="text-center p-6 relative hover:shadow-lg transition-shadow">
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-ocean text-white w-8 h-8 rounded-full flex items-center justify-center font-bold">
                    {step.step}
                  </div>
                </div>
                <CardContent className="pt-8 p-0">
                  <div className="bg-gradient-ocean p-3 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                    <step.icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-foreground mb-4">{step.title}</h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button size="lg" className="mr-4">
              Start Your Application
            </Button>
            <Button variant="outline" size="lg">
              Book Consultation
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gradient-ocean text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <Icon className="h-10 w-10 text-white mx-auto mb-4" />
                  <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
                  <div className="text-blue-100">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Credentials */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-foreground text-center mb-12">Our Credentials</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card className="p-6">
                <CardHeader className="p-0 mb-4">
                  <CardTitle>Professional Registration</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="space-y-2 mb-4">
                    <Badge variant="outline" className="mr-2">MARA Registered</Badge>
                    <Badge variant="outline" className="mr-2">OMARA Compliant</Badge>
                    <Badge variant="outline">Licensed Migration Agents</Badge>
                  </div>
                  <p className="text-muted-foreground">
                    All our migration agents are registered with the Migration Agents Registration Authority (MARA) 
                    and strictly follow the Code of Conduct laid out by OMARA.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="p-6">
                <CardHeader className="p-0 mb-4">
                  <CardTitle>Office Locations</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="space-y-4">
                    <div>
                      <div className="font-medium text-foreground">Perth Head Office</div>
                      <div className="text-sm text-muted-foreground">Shop 4a, 188 Newcastle Street</div>
                      <div className="text-sm text-muted-foreground">Perth WA 6000, Australia</div>
                    </div>
                    <div>
                      <div className="font-medium text-foreground">Penang Office</div>
                      <div className="text-sm text-muted-foreground">Malaysia</div>
                    </div>
                    <div>
                      <div className="font-medium text-foreground">Singapore Office</div>
                      <div className="text-sm text-muted-foreground">Singapore</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default About;