import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BookOpen, GraduationCap, FileText, Users, CheckCircle, Clock, Globe, Star } from 'lucide-react';


const StudyVisas = () => {
  const visaTypes = [
    {
      title: "Student Visa (Subclass 500)",
      description: "For international students studying full-time in Australia",
      duration: "For course duration + extra time",
      requirements: ["Enrollment confirmation", "English proficiency", "Financial evidence", "Health insurance"],
      icon: GraduationCap
    },
    {
      title: "Student Guardian Visa (Subclass 590)", 
      description: "For guardians of students under 18 years",
      duration: "Matches student visa duration",
      requirements: ["Relationship evidence", "Financial capacity", "Health insurance", "Character requirements"],
      icon: Users
    }
  ];

  const benefits = [
    { title: "Work Rights", description: "Work up to 48 hours per fortnight during studies", icon: Clock },
    { title: "World-Class Education", description: "Access to globally recognized qualifications", icon: Star },
    { title: "Pathway to PR", description: "Potential pathway to permanent residency", icon: Globe },
    { title: "Family Inclusion", description: "Include eligible family members", icon: Users }
  ];

  const processSteps = [
    "Choose course and institution",
    "Receive Confirmation of Enrollment (CoE)",
    "Prepare visa application documents", 
    "Lodge visa application online",
    "Attend biometrics and health checks",
    "Receive visa grant notification"
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero opacity-10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="secondary" className="mb-4">
              <BookOpen className="h-4 w-4 mr-2" />
              Education Visas
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-ocean bg-clip-text text-transparent">
              Study Visas for Australia
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Unlock world-class education opportunities in Australia with our comprehensive student visa services
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-gradient-ocean text-white">
                Start Your Application
              </Button>
              <Button size="lg" variant="outline">
                Book Consultation
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Visa Types */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Student Visa Types</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Choose the right visa category for your educational journey
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {visaTypes.map((visa) => (
              <Card key={visa.title} className="group hover:shadow-strong transition-all duration-300 border-2 hover:border-primary/20">
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 rounded-lg bg-gradient-ocean text-white">
                      <visa.icon className="h-6 w-6" />
                    </div>
                    <CardTitle className="text-xl">{visa.title}</CardTitle>
                  </div>
                  <CardDescription className="text-base">{visa.description}</CardDescription>
                  <Badge variant="outline" className="w-fit mt-2">{visa.duration}</Badge>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold mb-3">Key Requirements:</h4>
                  <ul className="space-y-2">
                    {visa.requirements.map((req, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                        <span className="text-sm">{req}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Study in Australia?</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Experience the benefits of studying in one of the world's top education destinations
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit) => (
              <Card key={benefit.title} className="text-center group hover:shadow-soft transition-all duration-300">
                <CardContent className="pt-6">
                  <div className="p-3 rounded-full bg-gradient-ocean text-white w-fit mx-auto mb-4 group-hover:scale-110 transition-transform">
                    <benefit.icon className="h-8 w-8" />
                  </div>
                  <h3 className="font-bold text-lg mb-2">{benefit.title}</h3>
                  <p className="text-muted-foreground text-sm">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Steps */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Application Process</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Follow our streamlined process to secure your student visa
            </p>
          </div>
          <div className="max-w-4xl mx-auto">
            <div className="grid gap-6">
              {processSteps.map((step, index) => (
                <div key={index} className="flex items-center gap-4 p-6 rounded-lg border bg-card hover:shadow-soft transition-all duration-300">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-ocean text-white flex items-center justify-center font-bold">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-lg">{step}</p>
                  </div>
                  <FileText className="h-5 w-5 text-muted-foreground" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-ocean text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Start Your Educational Journey?</h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Let our expert team guide you through every step of the student visa process
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary">
              Free Visa Assessment
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-primary" asChild>
              <a href="/contact">Contact Our Experts</a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default StudyVisas;