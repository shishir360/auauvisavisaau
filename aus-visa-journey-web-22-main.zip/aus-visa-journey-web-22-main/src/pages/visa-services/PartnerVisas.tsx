import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Heart, Users, FileText, Calendar, CheckCircle, Clock, Shield, Heart as Ring } from 'lucide-react';


const PartnerVisas = () => {
  const visaStages = [
    {
      title: "Temporary Partner Visa (Subclass 820)",
      description: "First stage - temporary visa while relationship is assessed",
      duration: "Temporary (18-24 months)",
      benefits: ["Work and study rights", "Medicare access", "Travel in/out of Australia", "Include dependent children"],
      icon: Clock
    },
    {
      title: "Permanent Partner Visa (Subclass 801)",
      description: "Second stage - permanent residency after relationship verification",
      duration: "Permanent",
      benefits: ["Permanent residency", "Path to citizenship", "Sponsor family members", "Full Medicare benefits"],
      icon: Shield
    }
  ];

  const relationshipTypes = [
    { title: "Married Couples", description: "Legally married to Australian citizen/resident", requirements: "Marriage certificate", icon: Ring },
    { title: "De Facto Partners", description: "Living together in genuine committed relationship", requirements: "12+ months together", icon: Heart },
    { title: "Same-Sex Couples", description: "Equal recognition for all relationship types", requirements: "Same criteria apply", icon: Users },
    { title: "Prospective Marriage", description: "Engaged to be married (Subclass 300)", requirements: "Intent to marry", icon: Calendar }
  ];

  const evidenceRequired = [
    "Joint financial commitments",
    "Shared household responsibilities", 
    "Social recognition of relationship",
    "Commitment to shared life",
    "Photos and communication records",
    "Statutory declarations from friends/family",
    "Joint bank accounts and assets",
    "Joint lease or mortgage"
  ];

  const processSteps = [
    { step: "Gather Evidence", description: "Collect comprehensive relationship evidence", icon: FileText },
    { step: "Lodge Application", description: "Submit temporary visa application (820)", icon: Calendar },
    { step: "Initial Assessment", description: "Immigration processes temporary visa", icon: Clock },
    { step: "Temporary Grant", description: "Receive temporary partner visa", icon: CheckCircle },
    { step: "Ongoing Evidence", description: "Continue relationship, gather more evidence", icon: Heart },
    { step: "Permanent Assessment", description: "Apply for permanent visa (801)", icon: Shield }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero opacity-10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="secondary" className="mb-4">
              <Heart className="h-4 w-4 mr-2" />
              Partner Migration
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-ocean bg-clip-text text-transparent">
              Partner Visas Australia
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Unite with your partner in Australia through our specialized partner visa services with expert guidance
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-gradient-ocean text-white">
                Start Partner Visa
              </Button>
              <Button size="lg" variant="outline">
                Relationship Assessment
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Two-Stage Process */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Two-Stage Partner Visa Process</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Partner visas follow a unique two-stage process from temporary to permanent residency
            </p>
          </div>
          <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {visaStages.map((stage, index) => (
              <Card key={stage.title} className="group hover:shadow-strong transition-all duration-300 border-2 hover:border-primary/20 relative">
                <div className="absolute -top-4 left-6">
                  <Badge className="bg-gradient-ocean text-white text-lg px-4 py-2">
                    Stage {index + 1}
                  </Badge>
                </div>
                <CardHeader className="pt-8">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 rounded-lg bg-gradient-ocean text-white">
                      <stage.icon className="h-6 w-6" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">{stage.title}</CardTitle>
                      <Badge variant="outline" className="mt-1">{stage.duration}</Badge>
                    </div>
                  </div>
                  <CardDescription className="text-base">{stage.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold mb-3">Key Benefits:</h4>
                  <ul className="space-y-2">
                    {stage.benefits.map((benefit, benefitIndex) => (
                      <li key={benefitIndex} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                        <span className="text-sm">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Relationship Types */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Eligible Relationships</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Australia recognizes various relationship types for partner visa applications
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {relationshipTypes.map((type) => (
              <Card key={type.title} className="text-center group hover:shadow-soft transition-all duration-300">
                <CardContent className="pt-6">
                  <div className="p-3 rounded-full bg-gradient-sunset text-white w-fit mx-auto mb-4 group-hover:scale-110 transition-transform">
                    <type.icon className="h-8 w-8" />
                  </div>
                  <h3 className="font-bold text-lg mb-2">{type.title}</h3>
                  <p className="text-muted-foreground text-sm mb-2">{type.description}</p>
                  <Badge variant="secondary" className="text-xs">{type.requirements}</Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Evidence Requirements */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Relationship Evidence</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Comprehensive evidence is crucial for a successful partner visa application
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              {evidenceRequired.map((evidence, index) => (
                <Card key={index} className="group hover:shadow-soft transition-all duration-300">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-ocean text-white flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <span className="font-medium">{evidence}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Process Timeline */}
      <section className="py-16 bg-gradient-ocean text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Application Process</h2>
            <p className="text-xl opacity-90 max-w-2xl mx-auto">
              Step-by-step guide through the partner visa application journey
            </p>
          </div>
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {processSteps.map((step, index) => (
                <Card key={index} className="bg-white/10 backdrop-blur border-white/20 group hover:bg-white/20 transition-all duration-300">
                  <CardContent className="p-6 text-center">
                    <div className="p-3 rounded-full bg-white/20 text-white w-fit mx-auto mb-4 group-hover:scale-110 transition-transform">
                      <step.icon className="h-8 w-8" />
                    </div>
                    <h3 className="font-bold text-lg mb-2">{step.step}</h3>
                    <p className="text-sm opacity-90">{step.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Processing Times */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Current Processing Times</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Estimated processing times for partner visa applications
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
              <Card className="group hover:shadow-soft transition-all duration-300">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-primary" />
                    Onshore Applications
                  </CardTitle>
                  <CardDescription>Applied from within Australia</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span>75% processed in:</span>
                      <Badge variant="secondary">20-29 months</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>90% processed in:</span>
                      <Badge variant="secondary">29-38 months</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="group hover:shadow-soft transition-all duration-300">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-primary" />
                    Offshore Applications
                  </CardTitle>
                  <CardDescription>Applied from outside Australia</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span>75% processed in:</span>
                      <Badge variant="secondary">12-18 months</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>90% processed in:</span>
                      <Badge variant="secondary">18-24 months</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-sunset text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Start Your Partner Visa Journey</h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Our expert team will guide you through every step of your partner visa application
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary">
              Free Relationship Assessment
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-primary" asChild>
              <a href="/contact">Speak to Partner Visa Expert</a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default PartnerVisas;