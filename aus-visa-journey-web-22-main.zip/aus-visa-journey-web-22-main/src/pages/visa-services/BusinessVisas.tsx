import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Building, TrendingUp, DollarSign, Users, CheckCircle, Briefcase, Target, Award } from 'lucide-react';


const BusinessVisas = () => {
  const visaTypes = [
    {
      title: "Business Innovation Visa (Subclass 188A)",
      description: "For business owners who want to establish/operate a business in Australia",
      investment: "From AUD $200,000",
      requirements: ["Business ownership", "Turnover requirements", "Innovation points", "Age under 55"],
      icon: Building
    },
    {
      title: "Investor Visa (Subclass 188B)",
      description: "For investors with strong investment experience and funds",
      investment: "AUD $2.5 million",
      requirements: ["Investment experience", "Net business assets", "Designated investment", "Age under 55"],
      icon: DollarSign
    },
    {
      title: "Significant Investor Visa (Subclass 188C)",
      description: "For high net worth individuals making substantial investments",
      investment: "AUD $5 million",
      requirements: ["Complying investment", "Lawful source of funds", "Maintained investment", "No age limit"],
      icon: TrendingUp
    },
    {
      title: "Premium Investor Visa (Subclass 188D)",
      description: "For ultra-high net worth individuals with exceptional investments",
      investment: "AUD $15 million",
      requirements: ["Premium investment", "Direct investment pathway", "Fast-track processing", "No age limit"],
      icon: Award
    }
  ];

  const benefits = [
    { title: "Business Growth", description: "Expand your business into Australian markets", icon: TrendingUp },
    { title: "Investment Returns", description: "Access high-quality investment opportunities", icon: DollarSign },
    { title: "Global Mobility", description: "Travel freely with Australian residency", icon: Target },
    { title: "Family Benefits", description: "Include family members in your application", icon: Users }
  ];

  const sectors = [
    "Technology & Innovation",
    "Healthcare & Biotechnology", 
    "Advanced Manufacturing",
    "Agribusiness & Food",
    "Infrastructure & Construction",
    "Financial Services",
    "Education & Training",
    "Tourism & Hospitality"
  ];

  const pathwaySteps = [
    { title: "Provisional Visa", description: "Receive 4-year provisional visa", icon: Briefcase },
    { title: "Business Activity", description: "Operate business or maintain investment", icon: Building },
    { title: "Meet Requirements", description: "Fulfill visa conditions and requirements", icon: CheckCircle },
    { title: "Permanent Residency", description: "Apply for permanent residency (888)", icon: Award }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero opacity-10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="secondary" className="mb-4">
              <Building className="h-4 w-4 mr-2" />
              Business Migration
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-ocean bg-clip-text text-transparent">
              Business & Investment Visas
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Grow your business and investments in Australia with our specialized business migration services
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-gradient-ocean text-white">
                Business Assessment
              </Button>
              <Button size="lg" variant="outline">
                Investment Guide
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Visa Types */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Business Visa Categories</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Choose the right business visa based on your investment capacity and business goals
            </p>
          </div>
          <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {visaTypes.map((visa) => (
              <Card key={visa.title} className="group hover:shadow-strong transition-all duration-300 border-2 hover:border-primary/20">
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-gradient-ocean text-white">
                        <visa.icon className="h-6 w-6" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{visa.title}</CardTitle>
                        <Badge variant="default" className="mt-1 bg-golden-yellow text-navy-dark">
                          {visa.investment}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <CardDescription className="text-base">{visa.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold mb-3">Key Requirements:</h4>
                  <ul className="space-y-2">
                    {visa.requirements.map((req, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                        <span className="text-sm">{req}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Business Migration Benefits</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Discover the advantages of establishing your business presence in Australia
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit) => (
              <Card key={benefit.title} className="text-center group hover:shadow-soft transition-all duration-300">
                <CardContent className="pt-6">
                  <div className="p-3 rounded-full bg-gradient-ocean text-white w-fit mx-auto mb-4 group-hover:scale-110 transition-transform">
                    <benefit.icon className="h-8 w-8" />
                  </div>
                  <h3 className="font-bold text-lg mb-2">{benefit.title}</h3>
                  <p className="text-muted-foreground text-sm">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Priority Sectors */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Priority Investment Sectors</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Australia welcomes investment in these high-growth industry sectors
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {sectors.map((sector, index) => (
              <Card key={index} className="group hover:shadow-soft transition-all duration-300 cursor-pointer">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-full bg-gradient-sunset text-white flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                    <TrendingUp className="h-6 w-6" />
                  </div>
                  <h3 className="font-semibold text-base">{sector}</h3>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pathway to Permanent Residency */}
      <section className="py-16 bg-gradient-ocean text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Pathway to Permanent Residency</h2>
            <p className="text-xl opacity-90 max-w-2xl mx-auto">
              Business visas provide a clear pathway from provisional to permanent residency
            </p>
          </div>
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {pathwaySteps.map((step, index) => (
                <Card key={index} className="bg-white/10 backdrop-blur border-white/20 text-center group hover:bg-white/20 transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-full bg-white/20 text-white flex items-center justify-center font-bold text-lg mx-auto mb-4">
                      {index + 1}
                    </div>
                    <div className="p-2 rounded-lg bg-white/10 text-white w-fit mx-auto mb-4">
                      <step.icon className="h-6 w-6" />
                    </div>
                    <h3 className="font-bold text-lg mb-2">{step.title}</h3>
                    <p className="text-sm opacity-90">{step.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Investment Requirements */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Investment Requirements</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Understanding the investment thresholds and compliance requirements
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
              <Card className="group hover:shadow-soft transition-all duration-300">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building className="h-5 w-5 text-primary" />
                    Business Innovation (188A)
                  </CardTitle>
                  <CardDescription>Establish or purchase an existing business</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span>Minimum investment:</span>
                      <Badge variant="secondary">AUD $200,000</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Business turnover:</span>
                      <Badge variant="secondary">AUD $750,000</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Net business assets:</span>
                      <Badge variant="secondary">AUD $200,000</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="group hover:shadow-soft transition-all duration-300">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-primary" />
                    Significant Investor (188C)
                  </CardTitle>
                  <CardDescription>Make complying investments in Australia</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span>Total investment:</span>
                      <Badge variant="secondary">AUD $5,000,000</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Venture capital:</span>
                      <Badge variant="secondary">20% minimum</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Investment period:</span>
                      <Badge variant="secondary">4 years</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-sunset text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Expand Your Business to Australia?</h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Our business migration specialists will help you choose the right visa and navigate the application process
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary">
              Free Business Assessment
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-primary" asChild>
              <a href="/contact">Speak to Business Expert</a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default BusinessVisas;