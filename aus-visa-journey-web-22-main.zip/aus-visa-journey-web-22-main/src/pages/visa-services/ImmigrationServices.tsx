import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FileText, Users, Scale, Clock, CheckCircle, Award, Shield, Briefcase } from 'lucide-react';


const ImmigrationServices = () => {
  const services = [
    {
      title: "Migration Planning & Strategy",
      description: "Comprehensive migration planning tailored to your goals",
      features: ["Eligibility assessment", "Pathway analysis", "Timeline planning", "Risk assessment"],
      icon: Briefcase
    },
    {
      title: "Document Preparation",
      description: "Expert assistance with visa application documentation",
      features: ["Document checklist", "Evidence compilation", "Translation services", "Quality review"],
      icon: FileText
    },
    {
      title: "Appeals & Reviews",
      description: "Professional representation for visa refusals and appeals",
      features: ["AAT representation", "Merits review", "Federal court matters", "Case analysis"],
      icon: Scale
    },
    {
      title: "Citizenship Applications",
      description: "Guidance through the Australian citizenship process",
      features: ["Eligibility check", "Application preparation", "Citizenship test prep", "Ceremony attendance"],
      icon: Award
    }
  ];

  const specializedServices = [
    { title: "Character Requirements", description: "Assistance with police clearances and character issues", icon: Shield },
    { title: "Health Examinations", description: "Guidance on medical requirements and health waivers", icon: Users },
    { title: "English Testing", description: "Support with IELTS, PTE, and other English proficiency tests", icon: FileText },
    { title: "Skills Assessment", description: "Help with skills assessment applications for various professions", icon: Award },
    { title: "State Nomination", description: "Assistance with state and territory nomination applications", icon: Briefcase },
    { title: "Employer Sponsorship", description: "Support for employers and employees in sponsorship processes", icon: Users }
  ];

  const processAdvantages = [
    "Expert knowledge of immigration law",
    "Reduced application processing times",
    "Higher success rates",
    "Comprehensive case management",
    "Regular application updates",
    "Post-visa landing support"
  ];

  const documentCategories = [
    { category: "Identity Documents", items: ["Passports", "Birth certificates", "Marriage certificates", "Name change documents"] },
    { category: "Education Records", items: ["Degree certificates", "Academic transcripts", "Skills assessments", "Professional certifications"] },
    { category: "Employment History", items: ["Employment letters", "Pay slips", "Tax returns", "Superannuation records"] },
    { category: "Financial Evidence", items: ["Bank statements", "Investment records", "Property valuations", "Income declarations"] }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero opacity-10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="secondary" className="mb-4">
              <Scale className="h-4 w-4 mr-2" />
              Professional Services
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-ocean bg-clip-text text-transparent">
              Immigration Services
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Comprehensive immigration support services beyond visa applications - from appeals to citizenship
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-gradient-ocean text-white">
                Consultation Booking
              </Button>
              <Button size="lg" variant="outline">
                Service Overview
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Core Services */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Core Immigration Services</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Professional immigration assistance covering all aspects of your migration journey
            </p>
          </div>
          <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {services.map((service) => (
              <Card key={service.title} className="group hover:shadow-strong transition-all duration-300 border-2 hover:border-primary/20">
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 rounded-lg bg-gradient-ocean text-white">
                      <service.icon className="h-6 w-6" />
                    </div>
                    <CardTitle className="text-xl">{service.title}</CardTitle>
                  </div>
                  <CardDescription className="text-base">{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {service.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Specialized Services */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Specialized Support Services</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Expert assistance with specific immigration requirements and challenges
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {specializedServices.map((service) => (
              <Card key={service.title} className="text-center group hover:shadow-soft transition-all duration-300">
                <CardContent className="pt-6">
                  <div className="p-3 rounded-full bg-gradient-sunset text-white w-fit mx-auto mb-4 group-hover:scale-110 transition-transform">
                    <service.icon className="h-8 w-8" />
                  </div>
                  <h3 className="font-bold text-lg mb-2">{service.title}</h3>
                  <p className="text-muted-foreground text-sm">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Document Preparation */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Document Preparation Services</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Comprehensive support with documentation requirements for visa applications
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {documentCategories.map((category) => (
              <Card key={category.category} className="group hover:shadow-soft transition-all duration-300">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5 text-primary" />
                    {category.category}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {category.items.map((item, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                        <span className="text-sm">{item}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Professional Services */}
      <section className="py-16 bg-gradient-ocean text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose Professional Immigration Services?</h2>
              <p className="text-xl opacity-90 max-w-2xl mx-auto">
                The advantages of working with qualified immigration professionals
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {processAdvantages.map((advantage, index) => (
                <Card key={index} className="bg-white/10 backdrop-blur border-white/20 group hover:bg-white/20 transition-all duration-300">
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 rounded-full bg-white/20 text-white flex items-center justify-center font-bold text-lg mx-auto mb-4">
                      {index + 1}
                    </div>
                    <p className="font-medium">{advantage}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Appeals & Reviews */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Appeals & Reviews</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Professional representation for visa refusals and administrative decisions
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="text-center group hover:shadow-soft transition-all duration-300">
                <CardContent className="pt-6">
                  <Scale className="h-16 w-16 mx-auto mb-4 text-primary" />
                  <h3 className="font-bold text-xl mb-2">AAT Reviews</h3>
                  <p className="text-muted-foreground text-sm mb-4">Administrative Appeals Tribunal representation</p>
                  <Badge variant="secondary">Expert Advocacy</Badge>
                </CardContent>
              </Card>
              
              <Card className="text-center group hover:shadow-soft transition-all duration-300">
                <CardContent className="pt-6">
                  <FileText className="h-16 w-16 mx-auto mb-4 text-primary" />
                  <h3 className="font-bold text-xl mb-2">Case Analysis</h3>
                  <p className="text-muted-foreground text-sm mb-4">Detailed review of refusal reasons and options</p>
                  <Badge variant="secondary">Strategic Planning</Badge>
                </CardContent>
              </Card>
              
              <Card className="text-center group hover:shadow-soft transition-all duration-300">
                <CardContent className="pt-6">
                  <Shield className="h-16 w-16 mx-auto mb-4 text-primary" />
                  <h3 className="font-bold text-xl mb-2">Federal Court</h3>
                  <p className="text-muted-foreground text-sm mb-4">Judicial review proceedings representation</p>
                  <Badge variant="secondary">Legal Expertise</Badge>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Citizenship Services */}
      <section className="py-16 bg-gradient-sunset text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Australian Citizenship Services</h2>
              <p className="text-xl opacity-90 max-w-2xl mx-auto">
                Complete support for your journey to Australian citizenship
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-2xl font-bold mb-4">Citizenship Process</h3>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5" />
                    <span>Eligibility assessment and advice</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5" />
                    <span>Application preparation and lodgement</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5" />
                    <span>Citizenship test preparation resources</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5" />
                    <span>Interview preparation and support</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5" />
                    <span>Ceremony attendance guidance</span>
                  </li>
                </ul>
                <Button variant="secondary" size="lg">
                  Start Citizenship Journey
                </Button>
              </div>
              <div>
                <Card className="bg-white/10 backdrop-blur border-white/20">
                  <CardContent className="p-6">
                    <Award className="h-16 w-16 mx-auto mb-4 text-white" />
                    <h3 className="font-bold text-xl mb-4 text-center">Citizenship Benefits</h3>
                    <ul className="space-y-2 text-sm">
                      <li>• Australian passport and travel freedom</li>
                      <li>• Voting rights in federal elections</li>
                      <li>• Access to government jobs</li>
                      <li>• Consular assistance overseas</li>
                      <li>• Never lose right to enter Australia</li>
                      <li>• Sponsor family members</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Get Professional Immigration Support</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Whether you need help with visas, appeals, or citizenship - our expert team is here to assist
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-gradient-ocean text-white">
              Book Consultation
            </Button>
            <Button size="lg" variant="outline" asChild>
              <a href="/contact">Contact Our Experts</a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ImmigrationServices;