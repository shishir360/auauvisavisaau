import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Heart, Users, Home, Baby, CheckCircle, Clock, Shield, Sparkles } from 'lucide-react';


const FamilyVisas = () => {
  const visaTypes = [
    {
      title: "Partner Visa (Subclass 820/801)",
      description: "For spouses and de facto partners of Australian citizens/residents",
      duration: "Temporary to Permanent",
      keyPoints: ["Relationship evidence required", "2-stage application", "Work rights included", "Path to citizenship"],
      icon: Heart
    },
    {
      title: "Child Visa (Subclass 802)",
      description: "For children of Australian citizens or permanent residents",
      duration: "Permanent",
      keyPoints: ["Under 18 or dependent", "Parent must be citizen/PR", "Immediate permanent residency", "Family unity"],
      icon: Baby
    },
    {
      title: "Parent Visa (Subclass 103/143)", 
      description: "For parents of Australian citizens or permanent residents",
      duration: "Permanent",
      keyPoints: ["Balance of family test", "Assurance of support", "Health insurance", "Long processing times"],
      icon: Users
    },
    {
      title: "Contributory Parent Visa (Subclass 173/143)",
      description: "Faster processing parent visa with higher fees",
      duration: "Temporary to Permanent",
      keyPoints: ["Faster processing", "Higher application fees", "Assurance of support", "Health requirements"],
      icon: Shield
    }
  ];

  const benefits = [
    { title: "Family Unity", description: "Keep your family together in Australia", icon: Home },
    { title: "Work Rights", description: "Full work rights for visa holders", icon: Sparkles },
    { title: "Healthcare Access", description: "Access to Medicare and healthcare", icon: Shield },
    { title: "Education Benefits", description: "Access to education for children", icon: Users }
  ];

  const relationshipTypes = [
    { type: "Married Couples", description: "Legally married partners", icon: Heart },
    { type: "De Facto Partners", description: "Living together in genuine relationship", icon: Users },
    { type: "Same-Sex Couples", description: "Equal recognition for all relationships", icon: Heart },
    { type: "Engaged Couples", description: "Prospective Marriage Visa pathway", icon: Sparkles }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero opacity-10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="secondary" className="mb-4">
              <Heart className="h-4 w-4 mr-2" />
              Family Migration
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-ocean bg-clip-text text-transparent">
              Family Visas Australia
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Reunite with your loved ones in Australia through our comprehensive family visa services
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-gradient-ocean text-white">
                Start Your Application
              </Button>
              <Button size="lg" variant="outline">
                Family Visa Assessment
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Visa Types */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Family Visa Categories</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Explore different family visa options to bring your loved ones to Australia
            </p>
          </div>
          <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {visaTypes.map((visa) => (
              <Card key={visa.title} className="group hover:shadow-strong transition-all duration-300 border-2 hover:border-primary/20">
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 rounded-lg bg-gradient-ocean text-white">
                      <visa.icon className="h-6 w-6" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">{visa.title}</CardTitle>
                      <Badge variant="outline" className="mt-1">{visa.duration}</Badge>
                    </div>
                  </div>
                  <CardDescription className="text-base">{visa.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {visa.keyPoints.map((point, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                        <span className="text-sm">{point}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Relationship Types */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Recognized Relationships</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Australia recognizes various relationship types for family visa applications
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {relationshipTypes.map((relationship) => (
              <Card key={relationship.type} className="text-center group hover:shadow-soft transition-all duration-300">
                <CardContent className="pt-6">
                  <div className="p-3 rounded-full bg-gradient-sunset text-white w-fit mx-auto mb-4 group-hover:scale-110 transition-transform">
                    <relationship.icon className="h-8 w-8" />
                  </div>
                  <h3 className="font-bold text-lg mb-2">{relationship.type}</h3>
                  <p className="text-muted-foreground text-sm">{relationship.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Family Visa Benefits</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Enjoy comprehensive benefits when your family joins you in Australia
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit) => (
              <Card key={benefit.title} className="text-center group hover:shadow-soft transition-all duration-300">
                <CardContent className="pt-6">
                  <div className="p-3 rounded-full bg-gradient-ocean text-white w-fit mx-auto mb-4 group-hover:scale-110 transition-transform">
                    <benefit.icon className="h-8 w-8" />
                  </div>
                  <h3 className="font-bold text-lg mb-2">{benefit.title}</h3>
                  <p className="text-muted-foreground text-sm">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-16 bg-gradient-sunset text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Application Timeline</h2>
              <p className="text-xl opacity-90 max-w-2xl mx-auto">
                Understanding typical processing times for family visa applications
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="bg-white/10 backdrop-blur border-white/20 text-center">
                <CardContent className="pt-6">
                  <Clock className="h-12 w-12 mx-auto mb-4 opacity-90" />
                  <h3 className="font-bold text-xl mb-2">Partner Visas</h3>
                  <p className="text-lg">12-24 months</p>
                  <p className="text-sm opacity-75 mt-2">2-stage process</p>
                </CardContent>
              </Card>
              <Card className="bg-white/10 backdrop-blur border-white/20 text-center">
                <CardContent className="pt-6">
                  <Clock className="h-12 w-12 mx-auto mb-4 opacity-90" />
                  <h3 className="font-bold text-xl mb-2">Child Visas</h3>
                  <p className="text-lg">12-18 months</p>
                  <p className="text-sm opacity-75 mt-2">Direct to permanent</p>
                </CardContent>
              </Card>
              <Card className="bg-white/10 backdrop-blur border-white/20 text-center">
                <CardContent className="pt-6">
                  <Clock className="h-12 w-12 mx-auto mb-4 opacity-90" />
                  <h3 className="font-bold text-xl mb-2">Parent Visas</h3>
                  <p className="text-lg">12+ years</p>
                  <p className="text-sm opacity-75 mt-2">Contributory: 4-6 years</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Bring Your Family to Australia</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Let our experienced team help you navigate the family visa process and reunite with your loved ones
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-gradient-ocean text-white">
              Get Family Visa Assessment
            </Button>
            <Button size="lg" variant="outline" asChild>
              <a href="/contact">Speak to Our Experts</a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default FamilyVisas;