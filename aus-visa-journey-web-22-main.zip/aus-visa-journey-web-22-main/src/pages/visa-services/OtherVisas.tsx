import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plane, Globe, Clock, Users, CheckCircle, Star, Shield, MapPin } from 'lucide-react';


const OtherVisas = () => {
  const visaTypes = [
    {
      title: "Visitor Visa (Subclass 600)",
      description: "For tourism, visiting family/friends, or short-term business",
      duration: "Up to 12 months",
      features: ["Multiple entry options", "Tourism activities", "Business meetings", "Family visits"],
      icon: Plane
    },
    {
      title: "Working Holiday Visa (Subclass 417/462)",
      description: "For young people to work and travel in Australia",
      duration: "12 months (extendable)",
      features: ["Age 18-30", "Work while traveling", "Study opportunities", "Cultural exchange"],
      icon: Globe
    },
    {
      title: "Transit Visa (Subclass 771)",
      description: "For travelers passing through Australia to another country",
      duration: "Up to 72 hours",
      features: ["Airport transit", "Short stopovers", "No entry to Australia", "Quick processing"],
      icon: Clock
    },
    {
      title: "Retirement Visa (Subclass 405)",
      description: "For self-funded retirees with substantial assets",
      duration: "4 years (renewable)",
      features: ["Age 55+", "Asset requirements", "Health insurance", "No work rights"],
      icon: Star
    }
  ];

  const specialVisas = [
    {
      title: "Graduate Visa (Subclass 485)",
      description: "For international students who have completed Australian studies",
      highlights: ["Post-study work rights", "Pathway to PR", "18 months to 4 years"],
      icon: Users
    },
    {
      title: "Global Talent Visa (Subclass 858)",
      description: "For highly skilled professionals in priority sectors",
      highlights: ["Fast-track processing", "Direct permanent residency", "No sponsorship required"],
      icon: Star
    },
    {
      title: "Distinguished Talent Visa (Subclass 124/858)",
      description: "For individuals with exceptional achievements",
      highlights: ["International recognition", "Outstanding ability", "Permanent residency"],
      icon: Shield
    }
  ];

  const visitorActivities = [
    "Tourism and sightseeing",
    "Visiting family and friends",
    "Short-term business meetings",
    "Attending conferences or events",
    "Medical treatment",
    "Transit through Australia"
  ];

  const workingHolidayCountries = [
    "United Kingdom", "Ireland", "Canada", "Japan", "South Korea", "Germany",
    "France", "Italy", "Sweden", "Norway", "Denmark", "Belgium", "Netherlands"
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero opacity-10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="secondary" className="mb-4">
              <Globe className="h-4 w-4 mr-2" />
              Special Categories
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-ocean bg-clip-text text-transparent">
              Other Visa Types
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Explore specialized visa options for tourism, working holidays, transit, and unique circumstances
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-gradient-ocean text-white">
                Find Your Visa
              </Button>
              <Button size="lg" variant="outline">
                Visa Eligibility Check
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Common Visa Types */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Popular Visa Categories</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Common visa types for temporary visits, work, and special purposes
            </p>
          </div>
          <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {visaTypes.map((visa) => (
              <Card key={visa.title} className="group hover:shadow-strong transition-all duration-300 border-2 hover:border-primary/20">
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 rounded-lg bg-gradient-ocean text-white">
                      <visa.icon className="h-6 w-6" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">{visa.title}</CardTitle>
                      <Badge variant="outline" className="mt-1">{visa.duration}</Badge>
                    </div>
                  </div>
                  <CardDescription className="text-base">{visa.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold mb-3">Key Features:</h4>
                  <ul className="space-y-2">
                    {visa.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Special Visa Categories */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Specialized Visa Programs</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Unique visa pathways for exceptional individuals and circumstances
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {specialVisas.map((visa) => (
              <Card key={visa.title} className="text-center group hover:shadow-soft transition-all duration-300">
                <CardContent className="pt-6">
                  <div className="p-3 rounded-full bg-gradient-sunset text-white w-fit mx-auto mb-4 group-hover:scale-110 transition-transform">
                    <visa.icon className="h-8 w-8" />
                  </div>
                  <h3 className="font-bold text-lg mb-2">{visa.title}</h3>
                  <p className="text-muted-foreground text-sm mb-4">{visa.description}</p>
                  <div className="space-y-1">
                    {visa.highlights.map((highlight, index) => (
                      <Badge key={index} variant="secondary" className="text-xs block">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Visitor Visa Activities */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Visitor Visa Activities</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                What you can do in Australia on a visitor visa
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {visitorActivities.map((activity, index) => (
                <Card key={index} className="group hover:shadow-soft transition-all duration-300">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-ocean text-white flex items-center justify-center text-sm font-bold">
                        <CheckCircle className="h-4 w-4" />
                      </div>
                      <span className="font-medium text-sm">{activity}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Working Holiday Countries */}
      <section className="py-16 bg-gradient-ocean text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Working Holiday Eligible Countries</h2>
            <p className="text-xl opacity-90 max-w-2xl mx-auto">
              Countries with working holiday agreements with Australia
            </p>
          </div>
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-4">
              {workingHolidayCountries.map((country, index) => (
                <Card key={index} className="bg-white/10 backdrop-blur border-white/20 text-center group hover:bg-white/20 transition-all duration-300">
                  <CardContent className="p-4">
                    <div className="p-2 rounded-lg bg-white/10 text-white w-fit mx-auto mb-2">
                      <MapPin className="h-5 w-5" />
                    </div>
                    <h3 className="font-semibold text-sm">{country}</h3>
                  </CardContent>
                </Card>
              ))}
            </div>
            <div className="text-center mt-8">
              <p className="text-lg opacity-90 mb-4">Age requirements: 18-30 years (18-35 for some countries)</p>
              <Button variant="secondary" size="lg">
                Check Your Eligibility
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Processing */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Processing Times</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Typical processing times for various visa types
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="text-center group hover:shadow-soft transition-all duration-300">
                <CardContent className="pt-6">
                  <Clock className="h-12 w-12 mx-auto mb-4 text-primary" />
                  <h3 className="font-bold text-lg mb-2">Visitor Visa</h3>
                  <p className="text-2xl font-bold text-primary mb-1">1-30 days</p>
                  <p className="text-sm text-muted-foreground">Standard processing</p>
                </CardContent>
              </Card>
              
              <Card className="text-center group hover:shadow-soft transition-all duration-300">
                <CardContent className="pt-6">
                  <Clock className="h-12 w-12 mx-auto mb-4 text-primary" />
                  <h3 className="font-bold text-lg mb-2">Transit Visa</h3>
                  <p className="text-2xl font-bold text-primary mb-1">1-7 days</p>
                  <p className="text-sm text-muted-foreground">Fast processing</p>
                </CardContent>
              </Card>
              
              <Card className="text-center group hover:shadow-soft transition-all duration-300">
                <CardContent className="pt-6">
                  <Clock className="h-12 w-12 mx-auto mb-4 text-primary" />
                  <h3 className="font-bold text-lg mb-2">Working Holiday</h3>
                  <p className="text-2xl font-bold text-primary mb-1">14-30 days</p>
                  <p className="text-sm text-muted-foreground">Online application</p>
                </CardContent>
              </Card>
              
              <Card className="text-center group hover:shadow-soft transition-all duration-300">
                <CardContent className="pt-6">
                  <Clock className="h-12 w-12 mx-auto mb-4 text-primary" />
                  <h3 className="font-bold text-lg mb-2">Graduate Visa</h3>
                  <p className="text-2xl font-bold text-primary mb-1">4-6 months</p>
                  <p className="text-sm text-muted-foreground">Complex assessment</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-sunset text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Need Help Choosing the Right Visa?</h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Our visa experts can help you determine the best visa option for your specific situation
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary">
              Free Visa Consultation
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-primary" asChild>
              <a href="/contact">Contact Our Team</a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default OtherVisas;