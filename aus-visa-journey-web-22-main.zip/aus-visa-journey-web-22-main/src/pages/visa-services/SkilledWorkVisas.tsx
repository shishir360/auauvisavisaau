import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Briefcase, Trophy, Target, Users, CheckCircle, TrendingUp, MapPin, Award } from 'lucide-react';


const SkilledWorkVisas = () => {
  const visaTypes = [
    {
      title: "Skilled Independent Visa (Subclass 189)",
      description: "Points-based permanent visa for skilled workers",
      type: "Permanent",
      requirements: ["Points test", "Skills assessment", "English proficiency", "Age under 45"],
      icon: Trophy
    },
    {
      title: "Skilled Nominated Visa (Subclass 190)", 
      description: "State nominated permanent visa for skilled workers",
      type: "Permanent",
      requirements: ["State nomination", "Points test", "Skills assessment", "English proficiency"],
      icon: MapPin
    },
    {
      title: "Skilled Regional Visa (Subclass 491)",
      description: "Provisional visa for skilled workers in regional areas",
      type: "Provisional",
      requirements: ["State/regional nomination", "Points test", "Skills assessment", "Regional commitment"],
      icon: Target
    },
    {
      title: "Employer Nomination Scheme (Subclass 186)",
      description: "Permanent visa for employer-sponsored skilled workers",
      type: "Permanent", 
      requirements: ["Employer sponsorship", "Skills assessment", "English proficiency", "Work experience"],
      icon: Briefcase
    }
  ];

  const advantages = [
    { title: "Permanent Residency", description: "Most visas lead to permanent residency", icon: Award },
    { title: "Work Anywhere", description: "Live and work anywhere in Australia", icon: MapPin },
    { title: "Career Growth", description: "Access to world-class career opportunities", icon: TrendingUp },
    { title: "Family Benefits", description: "Include family members in your application", icon: Users }
  ];

  const occupationCategories = [
    "Healthcare & Medical",
    "Engineering & Construction", 
    "Information Technology",
    "Education & Training",
    "Business & Finance",
    "Trade & Technical Skills",
    "Agriculture & Environment",
    "Creative & Design"
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero opacity-10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="secondary" className="mb-4">
              <Briefcase className="h-4 w-4 mr-2" />
              Professional Migration
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-ocean bg-clip-text text-transparent">
              Skilled & Work Visas
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Build your career in Australia with our expert skilled migration services for professionals and tradespeople
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-gradient-ocean text-white">
                Check Your Eligibility
              </Button>
              <Button size="lg" variant="outline">
                Skills Assessment Guide
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Visa Types Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Skilled Visa Pathways</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Choose the right pathway based on your skills, experience, and career goals
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {visaTypes.map((visa) => (
              <Card key={visa.title} className="group hover:shadow-strong transition-all duration-300 border-2 hover:border-primary/20">
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-gradient-ocean text-white">
                        <visa.icon className="h-6 w-6" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{visa.title}</CardTitle>
                        <Badge variant={visa.type === "Permanent" ? "default" : "secondary"} className="mt-1">
                          {visa.type}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <CardDescription className="text-base">{visa.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold mb-3">Key Requirements:</h4>
                  <ul className="space-y-2">
                    {visa.requirements.map((req, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                        <span className="text-sm">{req}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Advantages */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose Skilled Migration?</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Discover the benefits of Australia's skilled migration program
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {advantages.map((advantage) => (
              <Card key={advantage.title} className="text-center group hover:shadow-soft transition-all duration-300">
                <CardContent className="pt-6">
                  <div className="p-3 rounded-full bg-gradient-ocean text-white w-fit mx-auto mb-4 group-hover:scale-110 transition-transform">
                    <advantage.icon className="h-8 w-8" />
                  </div>
                  <h3 className="font-bold text-lg mb-2">{advantage.title}</h3>
                  <p className="text-muted-foreground text-sm">{advantage.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* In-Demand Occupations */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">In-Demand Occupations</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Explore high-demand professional categories with excellent migration prospects
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {occupationCategories.map((category, index) => (
              <Card key={index} className="group hover:shadow-soft transition-all duration-300 cursor-pointer">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-full bg-gradient-ocean text-white flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                    <Trophy className="h-6 w-6" />
                  </div>
                  <h3 className="font-semibold text-base">{category}</h3>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Points Calculator CTA */}
      <section className="py-16 bg-gradient-sunset text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Calculate Your Points</h2>
                <p className="text-xl mb-6 opacity-90">
                  Use our free points calculator to assess your eligibility for skilled migration visas
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5" />
                    <span>Instant assessment results</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5" />
                    <span>Personalized recommendations</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5" />
                    <span>Free expert consultation</span>
                  </li>
                </ul>
                <Button size="lg" variant="secondary">
                  Start Points Calculator
                </Button>
              </div>
              <div className="relative">
                <Card className="bg-white/10 backdrop-blur border-white/20">
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span>Age (25-32 years)</span>
                        <Badge variant="secondary">30 points</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>English (Proficient)</span>
                        <Badge variant="secondary">10 points</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Work Experience</span>
                        <Badge variant="secondary">15 points</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Education</span>
                        <Badge variant="secondary">15 points</Badge>
                      </div>
                      <div className="border-t border-white/30 pt-4">
                        <div className="flex justify-between items-center font-bold text-lg">
                          <span>Total Points</span>
                          <Badge variant="default" className="bg-golden-yellow text-navy-dark">70 points</Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Advance Your Career in Australia?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Our immigration experts will help you navigate the skilled migration process successfully
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-gradient-ocean text-white">
              Book Free Consultation
            </Button>
            <Button size="lg" variant="outline" asChild>
              <a href="/contact">Get Professional Advice</a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default SkilledWorkVisas;