import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { ContactForm } from '@/components/ContactForm';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  MessageCircle,
  ExternalLink
} from 'lucide-react';

const Contact = () => {
  const offices = [
    {
      title: 'Perth Head Office',
      address: 'Shop 4a, 188 Newcastle Street\nPerth WA 6000, Australia',
      phone: '+61 481 826 365',
      email: 'info@ausstudyvisa.com.au',
      hours: 'Mon to Fri: 9AM - 5PM\nSat: By Appointment Only\nSun: Closed'
    },
    {
      title: 'Penang Office',
      address: 'Penang, Malaysia',
      phone: '+60 123 456 789',
      email: 'penang@ausstudyvisa.com.au',
      hours: 'Mon to Fri: 9AM - 5PM\nWeekends: Closed'
    },
    {
      title: 'Singapore Office',
      address: 'Singapore',
      phone: '+65 1234 5678',
      email: 'singapore@ausstudyvisa.com.au',
      hours: 'Mon to Fri: 9AM - 5PM\nWeekends: Closed'
    }
  ];

  const contactMethods = [
    {
      icon: Phone,
      title: 'Phone Consultation',
      description: 'Speak directly with our migration agents',
      action: 'Call +61 481 826 365',
      color: 'text-primary'
    },
    {
      icon: Mail,
      title: 'Email Enquiry',
      description: 'Send us your questions and requirements',
      action: 'Email info@ausstudyvisa.com.au',
      color: 'text-accent'
    },
    {
      icon: MessageCircle,
      title: 'WhatsApp Chat',
      description: 'Quick responses to urgent queries',
      action: 'WhatsApp +61 481 826 365',
      color: 'text-golden-yellow'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-ocean text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-6">Contact Us</h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              Get in touch with our experienced migration agents. We're here to help you navigate your Australian visa journey.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Methods */}
      <section className="py-12 lg:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 mb-12 lg:mb-16">
            {contactMethods.map((method, index) => {
              const Icon = method.icon;
              return (
                <Card key={index} className="text-center shadow-soft border-0 hover:shadow-strong transition-all duration-300">
                  <CardContent className="p-6 lg:p-8">
                    <div className={`w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4 lg:mb-6`}>
                      <Icon className={`h-8 w-8 ${method.color}`} />
                    </div>
                    <h3 className="text-lg lg:text-xl font-semibold text-foreground mb-3">
                      {method.title}
                    </h3>
                    <p className="text-muted-foreground mb-4 lg:mb-6 text-sm lg:text-base">
                      {method.description}
                    </p>
                    <Button variant="outline" className="w-full text-sm lg:text-base">
                      {method.action}
                      <ExternalLink className="ml-2 h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Main Content Grid */}
      <section className="py-12 lg:py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
            {/* Contact Form */}
            <div className="order-2 lg:order-1">
              <ContactForm />
            </div>

            {/* Office Information */}
            <div className="space-y-6 lg:space-y-8 order-1 lg:order-2">
              <div>
                <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-6 lg:mb-8">Our Offices</h2>
                <div className="space-y-6 lg:space-y-8">
                  {offices.map((office, index) => (
                    <Card key={index} className="shadow-soft border-0">
                      <CardContent className="p-4 lg:p-6">
                        <h3 className="text-lg lg:text-xl font-semibold text-foreground mb-4">
                          {office.title}
                        </h3>
                        <div className="space-y-3">
                          <div className="flex items-start">
                            <MapPin className="h-5 w-5 text-muted-foreground mr-3 mt-0.5 flex-shrink-0" />
                            <span className="text-muted-foreground whitespace-pre-line text-sm lg:text-base">
                              {office.address}
                            </span>
                          </div>
                          <div className="flex items-center">
                            <Phone className="h-5 w-5 text-muted-foreground mr-3 flex-shrink-0" />
                            <span className="text-muted-foreground text-sm lg:text-base">{office.phone}</span>
                          </div>
                          <div className="flex items-center">
                            <Mail className="h-5 w-5 text-muted-foreground mr-3 flex-shrink-0" />
                            <span className="text-muted-foreground text-sm lg:text-base">{office.email}</span>
                          </div>
                          <div className="flex items-start">
                            <Clock className="h-5 w-5 text-muted-foreground mr-3 mt-0.5 flex-shrink-0" />
                            <span className="text-muted-foreground whitespace-pre-line text-sm lg:text-base">
                              {office.hours}
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Map Placeholder */}
              <Card className="shadow-soft border-0">
                <CardContent className="p-0">
                  <div className="h-48 lg:h-64 bg-muted rounded-lg flex items-center justify-center">
                    <div className="text-center text-muted-foreground">
                      <MapPin className="h-8 lg:h-12 w-8 lg:w-12 mx-auto mb-2 lg:mb-4" />
                      <p className="font-medium text-sm lg:text-base">Interactive Map</p>
                      <p className="text-xs lg:text-sm">Find us in Perth CBD</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-12 lg:py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl lg:text-3xl font-bold text-foreground text-center mb-8 lg:mb-12">
            Frequently Asked Questions
          </h2>
          <div className="space-y-4 lg:space-y-6">
            {[
              {
                question: "How long does a visa application take?",
                answer: "Processing times vary depending on the visa type. Student visas typically take 4-6 weeks, while skilled migration can take 8-12 months. We provide specific timelines during consultation."
              },
              {
                question: "Do I need to visit your office for consultation?",
                answer: "While we welcome in-person visits, we also offer phone and video consultations for your convenience, especially for interstate and overseas clients."
              },
              {
                question: "What documents do I need for my visa application?",
                answer: "Required documents vary by visa type. We provide a comprehensive checklist during consultation and can certify copies of your documents."
              },
              {
                question: "How much do your services cost?",
                answer: "Our fees vary depending on the complexity of your case. We offer transparent pricing and provide detailed quotes after initial consultation. Initial consultation is FREE."
              }
            ].map((faq, index) => (
              <Card key={index} className="shadow-soft border-0">
                <CardContent className="p-4 lg:p-6">
                  <h3 className="text-base lg:text-lg font-semibold text-foreground mb-2 lg:mb-3">
                    {faq.question}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed text-sm lg:text-base">
                    {faq.answer}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Contact;