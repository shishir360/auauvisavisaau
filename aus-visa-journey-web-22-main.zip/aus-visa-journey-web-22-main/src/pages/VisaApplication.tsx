import { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { 
  FileText, 
  User, 
  MapPin, 
  GraduationCap, 
  Users, 
  CheckCircle,
  AlertCircle,
  Upload,
  Phone,
  Mail
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const VisaApplication = () => {
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 5;

  const [formData, setFormData] = useState({
    // Personal Information
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    nationality: '',
    passportNumber: '',
    currentLocation: '',
    
    // Visa Information
    visaType: '',
    preferredStartDate: '',
    hasAppliedBefore: '',
    previousRefusal: '',
    
    // Education & Employment
    educationLevel: '',
    currentOccupation: '',
    workExperience: '',
    englishProficiency: '',
    
    // Family Information
    maritalStatus: '',
    dependents: '',
    
    // Additional Information
    healthConditions: '',
    criminalHistory: '',
    additionalInfo: '',
    
    // Agreements
    termsAccepted: false,
    privacyAccepted: false,
    marketingConsent: false
  });

  const visaTypes = [
    'Student Visa (Subclass 500)',
    'Skilled Independent Visa (Subclass 189)',
    'Skilled Nominated Visa (Subclass 190)',
    'Employer Nomination Scheme (Subclass 186)',
    'Partner Visa (Subclass 820/801)',
    'Parent Visa (Subclass 103)',
    'Business Innovation and Investment (Subclass 888)',
    'Working Holiday Visa (Subclass 417)',
    'Tourist Visa (Subclass 600)',
    'Other (Please specify in additional information)'
  ];

  const steps = [
    { number: 1, title: 'Personal Details', icon: User },
    { number: 2, title: 'Visa Information', icon: FileText },
    { number: 3, title: 'Background', icon: GraduationCap },
    { number: 4, title: 'Documents', icon: Upload },
    { number: 5, title: 'Review & Submit', icon: CheckCircle }
  ];

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    toast({
      title: "Application Submitted Successfully!",
      description: "We'll review your application and contact you within 24 hours.",
    });
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="firstName">First Name *</Label>
                <Input 
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                  placeholder="Enter your first name"
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="lastName">Last Name *</Label>
                <Input 
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                  placeholder="Enter your last name"
                  className="mt-2"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="email">Email Address *</Label>
                <Input 
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  placeholder="your.email@example.com"
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <Input 
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  placeholder="+61 400 000 000"
                  className="mt-2"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="dateOfBirth">Date of Birth *</Label>
                <Input 
                  id="dateOfBirth"
                  type="date"
                  value={formData.dateOfBirth}
                  onChange={(e) => setFormData({...formData, dateOfBirth: e.target.value})}
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="nationality">Nationality *</Label>
                <Select value={formData.nationality} onValueChange={(value) => setFormData({...formData, nationality: value})}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select your nationality" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="indian">Indian</SelectItem>
                    <SelectItem value="chinese">Chinese</SelectItem>
                    <SelectItem value="british">British</SelectItem>
                    <SelectItem value="malaysian">Malaysian</SelectItem>
                    <SelectItem value="singaporean">Singaporean</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="passportNumber">Passport Number *</Label>
                <Input 
                  id="passportNumber"
                  value={formData.passportNumber}
                  onChange={(e) => setFormData({...formData, passportNumber: e.target.value})}
                  placeholder="Enter passport number"
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="currentLocation">Current Location *</Label>
                <Input 
                  id="currentLocation"
                  value={formData.currentLocation}
                  onChange={(e) => setFormData({...formData, currentLocation: e.target.value})}
                  placeholder="City, Country"
                  className="mt-2"
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div>
              <Label htmlFor="visaType">Visa Type *</Label>
              <Select value={formData.visaType} onValueChange={(value) => setFormData({...formData, visaType: value})}>
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Select the visa you're applying for" />
                </SelectTrigger>
                <SelectContent>
                  {visaTypes.map((visa, index) => (
                    <SelectItem key={index} value={visa}>{visa}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="preferredStartDate">Preferred Start Date</Label>
              <Input 
                id="preferredStartDate"
                type="date"
                value={formData.preferredStartDate}
                onChange={(e) => setFormData({...formData, preferredStartDate: e.target.value})}
                className="mt-2"
              />
            </div>

            <div>
              <Label>Have you applied for an Australian visa before? *</Label>
              <RadioGroup 
                value={formData.hasAppliedBefore} 
                onValueChange={(value) => setFormData({...formData, hasAppliedBefore: value})}
                className="mt-3"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="yes" id="applied-yes" />
                  <Label htmlFor="applied-yes">Yes</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="no" id="applied-no" />
                  <Label htmlFor="applied-no">No</Label>
                </div>
              </RadioGroup>
            </div>

            <div>
              <Label>Have you ever been refused a visa to any country? *</Label>
              <RadioGroup 
                value={formData.previousRefusal} 
                onValueChange={(value) => setFormData({...formData, previousRefusal: value})}
                className="mt-3"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="yes" id="refused-yes" />
                  <Label htmlFor="refused-yes">Yes</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="no" id="refused-no" />
                  <Label htmlFor="refused-no">No</Label>
                </div>
              </RadioGroup>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="educationLevel">Highest Education Level *</Label>
                <Select value={formData.educationLevel} onValueChange={(value) => setFormData({...formData, educationLevel: value})}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select education level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high-school">High School</SelectItem>
                    <SelectItem value="diploma">Diploma/Certificate</SelectItem>
                    <SelectItem value="bachelor">Bachelor's Degree</SelectItem>
                    <SelectItem value="master">Master's Degree</SelectItem>
                    <SelectItem value="phd">PhD/Doctorate</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="englishProficiency">English Proficiency Test</Label>
                <Select value={formData.englishProficiency} onValueChange={(value) => setFormData({...formData, englishProficiency: value})}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select test type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ielts">IELTS</SelectItem>
                    <SelectItem value="toefl">TOEFL</SelectItem>
                    <SelectItem value="pte">PTE Academic</SelectItem>
                    <SelectItem value="cambridge">Cambridge English</SelectItem>
                    <SelectItem value="none">Not taken yet</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="currentOccupation">Current Occupation</Label>
              <Input 
                id="currentOccupation"
                value={formData.currentOccupation}
                onChange={(e) => setFormData({...formData, currentOccupation: e.target.value})}
                placeholder="Your current job title"
                className="mt-2"
              />
            </div>

            <div>
              <Label htmlFor="workExperience">Years of Work Experience</Label>
              <Select value={formData.workExperience} onValueChange={(value) => setFormData({...formData, workExperience: value})}>
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Select experience level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0-1">0-1 years</SelectItem>
                  <SelectItem value="2-3">2-3 years</SelectItem>
                  <SelectItem value="4-5">4-5 years</SelectItem>
                  <SelectItem value="6-8">6-8 years</SelectItem>
                  <SelectItem value="9+">9+ years</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="maritalStatus">Marital Status</Label>
                <Select value={formData.maritalStatus} onValueChange={(value) => setFormData({...formData, maritalStatus: value})}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="single">Single</SelectItem>
                    <SelectItem value="married">Married</SelectItem>
                    <SelectItem value="divorced">Divorced</SelectItem>
                    <SelectItem value="widowed">Widowed</SelectItem>
                    <SelectItem value="de-facto">De facto</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="dependents">Number of Dependents</Label>
                <Select value={formData.dependents} onValueChange={(value) => setFormData({...formData, dependents: value})}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select number" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">0</SelectItem>
                    <SelectItem value="1">1</SelectItem>
                    <SelectItem value="2">2</SelectItem>
                    <SelectItem value="3">3</SelectItem>
                    <SelectItem value="4+">4 or more</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-start">
                <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5 mr-3" />
                <div>
                  <h3 className="font-medium text-blue-900 mb-2">Required Documents</h3>
                  <ul className="text-sm text-blue-800 space-y-1">
                    <li>• Valid passport</li>
                    <li>• Recent passport-sized photographs</li>
                    <li>• Educational certificates and transcripts</li>
                    <li>• English proficiency test results (if applicable)</li>
                    <li>• Work experience letters</li>
                    <li>• Financial documents</li>
                    <li>• Health examination results</li>
                    <li>• Character certificates</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <FileText className="h-5 w-5 mr-2" />
                    Identity Documents
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors cursor-pointer">
                    <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-600">Click to upload passport and photos</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <GraduationCap className="h-5 w-5 mr-2" />
                    Education Documents
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors cursor-pointer">
                    <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-600">Upload certificates and transcripts</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Users className="h-5 w-5 mr-2" />
                    Work Experience
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors cursor-pointer">
                    <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-600">Upload employment letters and CV</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <MapPin className="h-5 w-5 mr-2" />
                    Other Documents
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors cursor-pointer">
                    <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-600">Financial and character documents</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Application Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Full Name</Label>
                    <p className="font-medium">{formData.firstName} {formData.lastName}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Email</Label>
                    <p className="font-medium">{formData.email}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Visa Type</Label>
                    <p className="font-medium">{formData.visaType}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Nationality</Label>
                    <p className="font-medium">{formData.nationality}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Terms and Conditions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Checkbox 
                    id="terms"
                    checked={formData.termsAccepted}
                    onCheckedChange={(checked) => setFormData({...formData, termsAccepted: checked as boolean})}
                  />
                  <Label htmlFor="terms" className="text-sm leading-relaxed">
                    I agree to the <span className="text-primary cursor-pointer hover:underline">Terms and Conditions</span> and understand that all information provided is accurate and complete.
                  </Label>
                </div>
                
                <div className="flex items-start space-x-3">
                  <Checkbox 
                    id="privacy"
                    checked={formData.privacyAccepted}
                    onCheckedChange={(checked) => setFormData({...formData, privacyAccepted: checked as boolean})}
                  />
                  <Label htmlFor="privacy" className="text-sm leading-relaxed">
                    I agree to the <span className="text-primary cursor-pointer hover:underline">Privacy Policy</span> and consent to the collection and use of my personal information.
                  </Label>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox 
                    id="marketing"
                    checked={formData.marketingConsent}
                    onCheckedChange={(checked) => setFormData({...formData, marketingConsent: checked as boolean})}
                  />
                  <Label htmlFor="marketing" className="text-sm leading-relaxed">
                    I consent to receiving marketing communications and updates about visa services (optional).
                  </Label>
                </div>
              </CardContent>
            </Card>

            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-600 mt-0.5 mr-3" />
                <div>
                  <h3 className="font-medium text-green-900 mb-2">What happens next?</h3>
                  <ul className="text-sm text-green-800 space-y-1">
                    <li>• We'll review your application within 24 hours</li>
                    <li>• One of our migration agents will contact you</li>
                    <li>• We'll schedule a free consultation</li>
                    <li>• You'll receive a detailed assessment report</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-ocean text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-6">Visa Application Form</h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              Start your Australian visa application with our simple, step-by-step form. 
              Our experts will review your application and provide personalized guidance.
            </p>
          </div>
        </div>
      </section>

      {/* Application Form */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Progress Steps */}
          <div className="mb-12">
            <div className="flex items-center justify-between mb-8">
              {steps.map((step) => {
                const Icon = step.icon;
                const isActive = currentStep === step.number;
                const isCompleted = currentStep > step.number;
                
                return (
                  <div key={step.number} className="flex flex-col items-center">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 transition-colors ${
                      isActive ? 'bg-primary text-white' : 
                      isCompleted ? 'bg-green-500 text-white' : 
                      'bg-muted text-muted-foreground'
                    }`}>
                      <Icon className="h-6 w-6" />
                    </div>
                    <span className={`text-sm font-medium hidden sm:block ${
                      isActive ? 'text-primary' : 
                      isCompleted ? 'text-green-500' : 
                      'text-muted-foreground'
                    }`}>
                      {step.title}
                    </span>
                  </div>
                );
              })}
            </div>
            
            <div className="relative">
              <div className="absolute top-0 left-0 h-2 bg-muted rounded-full w-full"></div>
              <div 
                className="absolute top-0 left-0 h-2 bg-primary rounded-full transition-all duration-300"
                style={{ width: `${(currentStep / totalSteps) * 100}%` }}
              ></div>
            </div>
          </div>

          {/* Form Content */}
          <Card className="shadow-strong border-0">
            <CardHeader>
              <CardTitle className="text-2xl">
                Step {currentStep}: {steps[currentStep - 1].title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {renderStep()}
              
              <Separator className="my-8" />
              
              {/* Navigation Buttons */}
              <div className="flex justify-between">
                <Button 
                  variant="outline" 
                  onClick={handlePrev}
                  disabled={currentStep === 1}
                >
                  Previous
                </Button>
                
                {currentStep === totalSteps ? (
                  <Button 
                    onClick={handleSubmit}
                    disabled={!formData.termsAccepted || !formData.privacyAccepted}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Submit Application
                    <CheckCircle className="ml-2 h-4 w-4" />
                  </Button>
                ) : (
                  <Button onClick={handleNext}>
                    Next Step
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Contact Support */}
          <Card className="mt-8 border-primary/20">
            <CardContent className="p-6">
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-4">Need Help with Your Application?</h3>
                <p className="text-muted-foreground mb-6">
                  Our migration experts are here to assist you every step of the way.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <div className="flex items-center justify-center">
                    <Phone className="h-4 w-4 mr-2 text-primary" />
                    <span className="text-sm">+61 481 826 365</span>
                  </div>
                  <div className="flex items-center justify-center">
                    <Mail className="h-4 w-4 mr-2 text-primary" />
                    <span className="text-sm">info@ausstudyvisa.com.au</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default VisaApplication;