import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  GraduationCap, 
  Users, 
  Briefcase, 
  Building, 
  Plane, 
  ArrowRight,
  CheckCircle,
  Clock,
  DollarSign
} from 'lucide-react';
import studyVisa from '@/assets/study-visa.jpg';
import familyVisa from '@/assets/family-visa.jpg';
import skilledVisa from '@/assets/skilled-visa.jpg';
import businessVisa from '@/assets/business-visa.jpg';

const Services = () => {
  const services = [
    {
      icon: GraduationCap,
      title: 'Study Visas',
      subtitle: 'Student Visa (Subclass 500)',
      description: 'We can assist with your study visa application and help with your relocation to Australia. Our comprehensive service includes school selection, application preparation, and post-arrival support.',
      image: studyVisa,
      features: [
        'School and course selection guidance',
        'Visa application preparation',
        'Document certification',
        'Post-arrival support',
        'Work rights explanation',
        'Pathway to permanent residency'
      ],
      processingTime: '4-6 weeks',
      startingPrice: 'From $1,500'
    },
    {
      icon: Users,
      title: 'Family Visas',
      subtitle: 'Partner & Family Reunion Visas',
      description: 'Australia is a safe and supportive country making it a fantastic place to raise your family. We help reunite families through various visa pathways.',
      image: familyVisa,
      features: [
        'Partner visa applications',
        'Parent visa options',
        'Child visa applications',
        'Relationship documentation',
        'Interview preparation',
        'Appeals and reviews'
      ],
      processingTime: '12-24 months',
      startingPrice: 'From $3,000'
    },
    {
      icon: Briefcase,
      title: 'Skilled & Work Visas',
      subtitle: 'Skilled Migration Pathways',
      description: 'Looking for amazing career opportunities and a fair workplace? Look no further than Australia. We help skilled professionals migrate through various pathways.',
      image: skilledVisa,
      features: [
        'Skills assessment guidance',
        'Points calculation',
        'Employer sponsorship',
        'State nomination assistance',
        'Expression of Interest',
        'Regional visa options'
      ],
      processingTime: '8-12 months',
      startingPrice: 'From $2,500'
    },
    {
      icon: Building,
      title: 'Business & Investment Visas',
      subtitle: 'Business Innovation & Investment',
      description: 'Australia provides a range of business investment visa options and we help get your application approved. Perfect for entrepreneurs and investors.',
      image: businessVisa,
      features: [
        'Business plan development',
        'Investment requirements',
        'Financial documentation',
        'State government nomination',
        'Compliance obligations',
        'Pathway to permanent residency'
      ],
      processingTime: '12-18 months',
      startingPrice: 'From $5,000'
    },
    {
      icon: Plane,
      title: 'Other Visa Options',
      subtitle: 'Working Holiday & Tourist Visas',
      description: 'Looking for travel or working holiday visas? S&S Consultation Pvt. Ltd can assist with various visa types for short-term stays and working holidays.',
      image: studyVisa,
      features: [
        'Working holiday visas',
        'Tourist visa applications',
        'Transit visa assistance',
        'Visitor visa extensions',
        'Electronic Travel Authority',
        'Special purpose visas'
      ],
      processingTime: '1-4 weeks',
      startingPrice: 'From $500'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-ocean text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-6">Our Services</h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              Comprehensive Australian visa services to help you achieve your immigration goals. 
              From study visas to permanent residency, we're here to guide you every step of the way.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-8 lg:space-y-12">
            {services.map((service, index) => {
              const Icon = service.icon;
              const isEven = index % 2 === 0;
              
              return (
                <Card key={index} className="overflow-hidden shadow-strong border-0">
                  <div className={`grid grid-cols-1 lg:grid-cols-2 ${!isEven ? 'lg:grid-flow-col-dense' : ''}`}>
                    <div className={`relative h-64 sm:h-80 lg:h-auto ${!isEven ? 'lg:col-start-2' : ''}`}>
                      <img 
                        src={service.image} 
                        alt={service.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent lg:hidden" />
                    </div>
                    
                    <div className="p-6 sm:p-8 lg:p-12 flex flex-col justify-center">
                      <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-0 mb-4">
                        <Icon className="h-8 w-8 text-primary sm:mr-3" />
                        <Badge variant="outline" className="self-start sm:self-auto">{service.subtitle}</Badge>
                      </div>
                      
                      <CardHeader className="p-0 mb-4 lg:mb-6">
                        <CardTitle className="text-2xl lg:text-3xl font-bold text-foreground">
                          {service.title}
                        </CardTitle>
                      </CardHeader>
                      
                      <CardContent className="p-0">
                        <p className="text-muted-foreground mb-4 lg:mb-6 leading-relaxed">
                          {service.description}
                        </p>
                        
                        <div className="grid grid-cols-1 gap-3 mb-4 lg:mb-6">
                          {service.features.map((feature, idx) => (
                            <div key={idx} className="flex items-center">
                              <CheckCircle className="h-4 w-4 text-primary mr-3 flex-shrink-0" />
                              <span className="text-sm text-muted-foreground">{feature}</span>
                            </div>
                          ))}
                        </div>
                        
                        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 mb-4 lg:mb-6">
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 text-muted-foreground mr-2" />
                            <span className="text-sm font-medium">{service.processingTime}</span>
                          </div>
                          <div className="flex items-center">
                            <DollarSign className="h-4 w-4 text-muted-foreground mr-2" />
                            <span className="text-sm font-medium">{service.startingPrice}</span>
                          </div>
                        </div>
                        
                        <div className="flex flex-col sm:flex-row gap-3">
                          <Button className="flex-1 sm:flex-none">
                            Learn More
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                          <Button variant="outline" className="flex-1 sm:flex-none">
                            Apply Now
                          </Button>
                        </div>
                      </CardContent>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 lg:py-20 bg-gradient-sunset">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-navy-dark mb-4 lg:mb-6">
            Ready to Start Your Australian Journey?
          </h2>
          <p className="text-lg lg:text-xl text-navy-dark/80 mb-6 lg:mb-8">
            Book a free consultation with our experienced migration agents today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="outline" className="border-navy-dark text-navy-dark hover:bg-navy-dark hover:text-white px-6 lg:px-8 py-4 lg:py-6 text-base lg:text-lg">
              Book Free Consultation
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button size="lg" className="bg-navy-dark hover:bg-navy-dark/90 text-white px-6 lg:px-8 py-4 lg:py-6 text-base lg:text-lg">
              Apply Now
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Services;