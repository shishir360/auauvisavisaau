import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, User, ArrowRight, Clock } from 'lucide-react';

const Blog = () => {
  const posts = [
    {
      title: "Australia Increases Student Visa Application Fees",
      excerpt: "The Australian government has announced changes to student visa fees starting July 2024. Here's what international students need to know about the new fees and application process.",
      category: "Student Visas",
      date: "March 15, 2024",
      author: "Migration Team",
      readTime: "5 min read",
      featured: true
    },
    {
      title: "New Skilled Migration Pathways for 2024",
      excerpt: "Discover the latest updates to Australia's skilled migration program, including new occupation lists and state nomination requirements for permanent residency.",
      category: "Skilled Migration",
      date: "March 10, 2024", 
      author: "Sarah Johnson",
      readTime: "7 min read",
      featured: true
    },
    {
      title: "Partner Visa Processing Times Update",
      excerpt: "Current processing times for partner visas have been updated. Learn about the latest changes and how to strengthen your application for faster processing.",
      category: "Family Visas",
      date: "March 5, 2024",
      author: "David Chen",
      readTime: "4 min read",
      featured: false
    },
    {
      title: "Working Holiday Visa: Everything You Need to Know",
      excerpt: "A comprehensive guide to working holiday visas in Australia, including eligibility requirements, application process, and what to expect upon arrival.",
      category: "Working Holiday",
      date: "February 28, 2024",
      author: "Emma Wilson",
      readTime: "6 min read",
      featured: false
    },
    {
      title: "Business Innovation and Investment Visa Changes",
      excerpt: "Recent changes to business and investment visas affect entrepreneurs and investors. Find out how these changes might impact your application.",
      category: "Business Visas",
      date: "February 20, 2024",
      author: "Michael Brown",
      readTime: "8 min read",
      featured: false
    },
    {
      title: "Study in Australia: Top Universities and Courses",
      excerpt: "Explore the best universities and courses for international students, including scholarship opportunities and post-study work options.",
      category: "Education",
      date: "February 15, 2024",
      author: "Lisa Wang",
      readTime: "10 min read",
      featured: false
    }
  ];

  const categories = [
    "All Posts",
    "Student Visas", 
    "Skilled Migration",
    "Family Visas",
    "Business Visas",
    "Working Holiday",
    "Education"
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-ocean text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-6">Immigration News & Updates</h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              Stay informed with the latest Australian immigration news, visa updates, and helpful guides from our experienced migration agents.
            </p>
          </div>
        </div>
      </section>

      {/* Categories Filter */}
      <section className="py-6 lg:py-8 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap gap-2 lg:gap-3 justify-center">
            {categories.map((category, index) => (
              <Badge 
                key={index} 
                variant={index === 0 ? "default" : "outline"}
                className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors px-3 lg:px-4 py-2 text-xs lg:text-sm"
              >
                {category}
              </Badge>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Posts */}
      <section className="py-12 lg:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-8 lg:mb-12">Featured Articles</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8 mb-12 lg:mb-16">
            {posts.filter(post => post.featured).map((post, index) => (
              <Card key={index} className="shadow-strong border-0 overflow-hidden hover:shadow-xl transition-all duration-300">
                <div className="h-40 lg:h-48 bg-gradient-sunset"></div>
                <CardHeader className="pb-3 lg:pb-4">
                  <div className="flex items-center justify-between mb-3">
                    <Badge variant="outline" className="text-xs lg:text-sm">{post.category}</Badge>
                    <div className="flex items-center text-xs lg:text-sm text-muted-foreground">
                      <Clock className="h-3 lg:h-4 w-3 lg:w-4 mr-1" />
                      {post.readTime}
                    </div>
                  </div>
                  <CardTitle className="text-lg lg:text-xl hover:text-primary transition-colors cursor-pointer">
                    {post.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground leading-relaxed mb-4 text-sm lg:text-base">
                    {post.excerpt}
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex flex-col sm:flex-row sm:items-center text-xs lg:text-sm text-muted-foreground space-y-1 sm:space-y-0 sm:space-x-4">
                      <div className="flex items-center">
                        <Calendar className="h-3 lg:h-4 w-3 lg:w-4 mr-1" />
                        {post.date}
                      </div>
                      <div className="flex items-center">
                        <User className="h-3 lg:h-4 w-3 lg:w-4 mr-1" />
                        {post.author}
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" className="text-xs lg:text-sm">
                      Read More
                      <ArrowRight className="ml-2 h-3 lg:h-4 w-3 lg:w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* All Posts */}
      <section className="py-12 lg:py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-8 lg:mb-12">All Articles</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {posts.map((post, index) => (
              <Card key={index} className="shadow-soft border-0 hover:shadow-strong transition-all duration-300">
                <div className="h-24 lg:h-32 bg-gradient-ocean"></div>
                <CardHeader className="pb-2 lg:pb-3">
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="outline" className="text-xs">{post.category}</Badge>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Clock className="h-3 w-3 mr-1" />
                      {post.readTime}
                    </div>
                  </div>
                  <CardTitle className="text-base lg:text-lg hover:text-primary transition-colors cursor-pointer leading-tight">
                    {post.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-xs lg:text-sm leading-relaxed mb-4">
                    {post.excerpt.substring(0, 120)}...
                  </p>
                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
                    <div className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      {post.date}
                    </div>
                    <div className="flex items-center">
                      <User className="h-3 w-3 mr-1" />
                      {post.author}
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" className="w-full text-xs lg:text-sm">
                    Read Full Article
                    <ArrowRight className="ml-2 h-3 lg:h-4 w-3 lg:w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-12 lg:py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-gradient-sunset rounded-2xl p-6 lg:p-8">
            <h2 className="text-2xl lg:text-3xl font-bold text-navy-dark mb-3 lg:mb-4">
              Stay Updated with Immigration News
            </h2>
            <p className="text-navy-dark/80 text-base lg:text-lg mb-4 lg:mb-6">
              Subscribe to our newsletter and get the latest visa updates and immigration news delivered to your inbox.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 lg:gap-4 max-w-md mx-auto">
              <input 
                type="email" 
                placeholder="Enter your email"
                className="flex-1 px-3 lg:px-4 py-2 lg:py-3 rounded-lg border border-navy-dark/20 focus:outline-none focus:ring-2 focus:ring-navy-dark text-sm lg:text-base"
              />
              <Button className="bg-navy-dark hover:bg-navy-dark/90 text-white px-4 lg:px-6 py-2 lg:py-3 text-sm lg:text-base">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Blog;