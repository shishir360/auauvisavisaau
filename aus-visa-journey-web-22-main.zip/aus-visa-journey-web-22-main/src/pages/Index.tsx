import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { ServicesSection } from '@/components/ServicesSection';
import { WhyChooseUs } from '@/components/WhyChooseUs';
import { ContactForm } from '@/components/ContactForm';
import { Footer } from '@/components/Footer';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Star, Users, CheckCircle, Globe, Award, Clock } from 'lucide-react';
import teamPhoto from '@/assets/team-photo.jpg';
import studyVisa from '@/assets/study-visa.jpg';
import familyVisa from '@/assets/family-visa.jpg';
import skilledVisa from '@/assets/skilled-visa.jpg';
import businessVisa from '@/assets/business-visa.jpg';

const Index = () => {
  const visaTypes = [
    {
      title: "Study Visa",
      description: "Complete guidance for student visa applications",
      image: studyVisa,
      overlay: "Study in Australia"
    },
    {
      title: "Skilled & Work Visa",
      description: "Professional migration pathways",
      image: skilledVisa,
      overlay: "Work in Australia"
    },
    {
      title: "Family Visa", 
      description: "Reunite with your loved ones",
      image: familyVisa,
      overlay: "Family Reunion"
    },
    {
      title: "Business Visa",
      description: "Investment and business opportunities",
      image: businessVisa,
      overlay: "Business Migration"
    }
  ];

  const benefits = [
    {
      icon: Users,
      title: "Over 1000 Visas",
      subtitle: "Approved Successfully",
      description: "We have successfully approved over 1000 visas with our expert guidance and proven strategies."
    },
    {
      icon: Award,
      title: "Registered Agents",
      subtitle: "MARA Certified",
      description: "Our team consists of registered migration agents certified by MARA (Migration Agents Registration Authority)."
    },
    {
      icon: Globe,
      title: "Multi Office Presence",
      subtitle: "Perth, Malaysia, Singapore", 
      description: "We have established offices across multiple countries to serve our international clients better."
    },
    {
      icon: Clock,
      title: "Experienced Team",
      subtitle: "Over 20 Years Experience",
      description: "Two decades of combined experience in Australian immigration and visa applications."
    },
    {
      icon: CheckCircle,
      title: "Document Experts",
      subtitle: "Comprehensive Support",
      description: "Expert assistance with document preparation, review, and submission for all visa types."
    },
    {
      icon: Star,
      title: "Australian Visas",
      subtitle: "All Categories Covered",
      description: "We handle all types of Australian visas including student, skilled, family, and business visas."
    }
  ];

  const testimonials = [
    {
      name: "Sarah Chen",
      country: "Singapore", 
      visaType: "Student Visa",
      text: "Amazing service! They helped me get my student visa approved in just 6 weeks. Highly professional team.",
      rating: 5
    },
    {
      name: "Raj Patel",
      country: "India",
      visaType: "Skilled Visa", 
      text: "Excellent guidance throughout the entire process. They made my PR application stress-free.",
      rating: 5
    },
    {
      name: "Maria Santos",
      country: "Philippines",
      visaType: "Family Visa",
      text: "Professional and caring service. They reunited me with my family in Australia. Thank you!",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <Hero />
      
      {/* We Simplify the Visa Process */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">
                We simplify the <span className="text-primary">visa process</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Our expert team guides you through every step of your Australian visa application process. 
                From initial consultation to final approval, we ensure your journey is smooth and successful.
              </p>
              <div className="space-y-4">
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-primary mr-3" />
                  <span className="text-muted-foreground">Expert consultation and assessment</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-primary mr-3" />
                  <span className="text-muted-foreground">Document preparation and review</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-primary mr-3" />
                  <span className="text-muted-foreground">Application submission and tracking</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-primary mr-3" />
                  <span className="text-muted-foreground">Post-approval support and guidance</span>
                </div>
              </div>
              <Button className="mt-8" size="lg">
                Start Your Application
              </Button>
            </div>
            
            {/* Visa Types Grid */}
            <div className="grid grid-cols-2 gap-4">
              {visaTypes.map((visa, index) => (
                <Card key={index} className="group overflow-hidden cursor-pointer hover:shadow-lg transition-all duration-300">
                  <div className="relative">
                    <img 
                      src={visa.image} 
                      alt={visa.title}
                      className="w-full h-32 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                      <div className="p-3">
                        <h3 className="text-white font-semibold text-sm">{visa.overlay}</h3>
                      </div>
                    </div>
                  </div>
                  <CardContent className="p-3">
                    <h4 className="font-medium text-sm mb-1">{visa.title}</h4>
                    <p className="text-xs text-muted-foreground">{visa.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      <WhyChooseUs />

      {/* Enhanced Benefits Section */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              Why Choose Us?
            </h2>
            <p className="text-lg text-muted-foreground">
              Benefit from our 20 years experience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center p-6 hover:shadow-lg transition-shadow">
                <div className="bg-gradient-ocean p-3 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <benefit.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">{benefit.title}</h3>
                <p className="text-primary font-semibold mb-3">{benefit.subtitle}</p>
                <p className="text-muted-foreground text-sm leading-relaxed">{benefit.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>
      
      {/* Local Team Section */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">
                Your Local <span className="text-primary">Visa Specialists</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                Our company head office is prominently situated on the corner of Newcastle Street and William Street in Perth CBD, Western Australia. Our offshore offices are located in Penang (Malaysia) and Singapore.
              </p>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                We empathize with our clients, and we look into all the needs of new migrants, be it temporary migrants such as students or permanent migrants bringing their families to live in Australia.
              </p>
              <Button variant="outline" size="lg">
                Visit Our Office
              </Button>
            </div>
            <div>
              <Card className="shadow-strong border-0 overflow-hidden">
                <img 
                  src={teamPhoto} 
                  alt="S&S Consultation Team"
                  className="w-full h-80 object-cover"
                />
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-2">Experienced Migration Agents</h3>
                  <p className="text-muted-foreground">
                    Our Perth-based team of registered migration agents with over 20 years of combined experience.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Happy Clients Section */}
      <section className="py-16 bg-gradient-ocean text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Our Happy Clients
            </h2>
            <p className="text-xl text-blue-100">
              Success stories from around the world
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white/10 backdrop-blur border-white/20 text-white">
                <CardContent className="p-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-blue-100 mb-6 italic">"{testimonial.text}"</p>
                  <div>
                    <h4 className="font-semibold">{testimonial.name}</h4>
                    <p className="text-blue-200 text-sm">{testimonial.country}</p>
                    <p className="text-yellow-300 text-sm font-medium">{testimonial.visaType}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button variant="secondary" size="lg" className="bg-white text-primary hover:bg-gray-100">
              View More Testimonials
            </Button>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <ContactForm />
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
